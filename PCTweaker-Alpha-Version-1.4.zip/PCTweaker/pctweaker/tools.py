"""One-shot actions and the admin tool launchers."""
import os
import subprocess
import time
from dataclasses import dataclass
from typing import Callable, Optional

from .admin import CREATE_NO_WINDOW, powershell, run_elevated, run_hidden, shell_run
from .debloat import remove_recommended
from .debloat_tools import reinstall_onedrive, remove_onedrive
from .network import latency_test, restart_adapters


@dataclass
class ActionItem:
    id: str
    name: str
    desc: str
    category: str
    run: Optional[Callable[[], str]] = None
    admin: bool = False
    button: str = "Run"
    confirm: Optional[str] = None
    ui: Optional[str] = None           # special UI handler, e.g. "appx"
    kind: str = "action"


def _fmt_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


def clean_temp() -> str:
    freed, skipped = 0, 0
    folders = {os.environ.get("TEMP"), os.environ.get("TMP"),
               os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Temp")}
    for folder in filter(None, folders):
        if not os.path.isdir(folder):
            continue
        for root, dirs, files in os.walk(folder, topdown=False):
            for f in files:
                p = os.path.join(root, f)
                try:
                    size = os.path.getsize(p)
                    os.remove(p)
                    freed += size
                except OSError:
                    skipped += 1
            for d in dirs:
                try:
                    os.rmdir(os.path.join(root, d))
                except OSError:
                    pass
    return f"Cleaned temporary files: freed {_fmt_bytes(freed)} ({skipped} in-use items skipped)."


def flush_dns() -> str:
    rc, out = run_hidden(["ipconfig.exe", "/flushdns"])
    if rc != 0:
        raise RuntimeError(out.strip() or "ipconfig failed")
    return "DNS cache flushed."


def restore_point() -> str:
    rc, out = powershell(
        'Checkpoint-Computer -Description "PC Tweaker" -RestorePointType MODIFY_SETTINGS '
        "-ErrorAction Stop", timeout=240)
    if rc != 0:
        raise RuntimeError(
            (out.strip() or "Unknown error") +
            "\n\nTip: System Protection must be switched on for your Windows drive "
            "(System Properties > System Protection).")
    return "Restore point created."


def sfc_scan() -> str:
    ok = run_elevated("cmd.exe", "/k sfc /scannow")
    if not ok:
        raise RuntimeError("Could not open an elevated console (was the UAC prompt declined?).")
    return "Opened an elevated console running System File Checker."


def dism_repair() -> str:
    ok = run_elevated("cmd.exe", "/k DISM /Online /Cleanup-Image /RestoreHealth")
    if not ok:
        raise RuntimeError("Could not open an elevated console (was the UAC prompt declined?).")
    return "Opened an elevated console running DISM RestoreHealth."


def restart_explorer() -> str:
    run_hidden(["taskkill.exe", "/f", "/im", "explorer.exe"])
    for _ in range(8):
        time.sleep(0.5)
        _, out = run_hidden(["tasklist.exe", "/fi", "imagename eq explorer.exe"])
        if "explorer.exe" in out.lower():
            return "Explorer restarted."
    subprocess.Popen(["explorer.exe"], creationflags=CREATE_NO_WINDOW)
    return "Explorer restarted."


# --------------------------------------------------------------------------- actions
ACTIONS = [
    ActionItem("clean_temp", "Clean temporary files",
               "Deletes files in your Temp folder and C:\\Windows\\Temp. Items in use are skipped. "
               "Run as administrator to clean the Windows Temp folder too.",
               "boost", clean_temp, button="Clean"),
    ActionItem("flush_dns", "Flush DNS cache",
               "Clears cached name lookups. Handy if sites or game servers fail to resolve.",
               "boost", flush_dns, admin=True, button="Flush"),
    # ---- debloat: apps & programs
    ActionItem("remove_apps", "Choose apps & features to remove",
               "Lists what is actually installed - Calculator, Weather, Photos, Solitaire, Teams, Internet "
               "Explorer and more - and lets you tick exactly what goes. Presets: Recommended or All non-essential.",
               "debloat_apps", admin=True, button="Choose...", ui="appx"),
    ActionItem("auto_apps", "Remove recommended clutter (one click)",
               "Removes the installed Microsoft clutter apps (News, Weather, Solitaire, Teams, Clipchamp...). "
               "Calculator, Photos and other everyday apps are left alone.",
               "debloat_apps", remove_recommended, admin=True, button="Remove",
               confirm="Remove every recommended clutter app that is installed on this PC? "
                       "You can reinstall any of them from the Microsoft Store."),
    ActionItem("programs", "Installed programs scanner",
               "Lists desktop programs, flags likely OEM / trial software (McAfee, Norton, preinstalled "
               "helpers) and uninstalls with one click.",
               "debloat_apps", button="Scan...", ui="programs"),
    ActionItem("onedrive_remove", "Remove OneDrive",
               "Uninstalls OneDrive. Blocked automatically if your Desktop, Documents or Pictures are backed "
               "up to it. Files already in your OneDrive folder stay on disk.",
               "debloat_apps", remove_onedrive, button="Remove",
               confirm="Uninstall OneDrive? Files already in your OneDrive folder stay on disk, and you can "
                       "reinstall it from this page."),
    ActionItem("onedrive_restore", "Reinstall OneDrive",
               "Runs the OneDrive installer that Windows keeps on disk.",
               "debloat_apps", reinstall_onedrive, button="Reinstall"),
    # ---- debloat: startup & background
    ActionItem("startup", "Startup manager",
               "See everything that launches with Windows and switch entries off (or back on) - the same "
               "switch Task Manager uses, so nothing is deleted.",
               "debloat_startup", button="Open...", ui="startup"),
    ActionItem("tasks", "Scheduled task cleaner",
               "Turn off telemetry and 'customer experience' tasks in Task Scheduler. Re-enable any time.",
               "debloat_startup", button="Open...", ui="tasks"),
    ActionItem("services", "Services viewer",
               "Optional Windows services in plain English. Set each to Auto, Manual or Off; 'Restore "
               "originals' puts everything back.",
               "debloat_startup", button="Open...", ui="services"),
    ActionItem("context", "Context-menu cleaner",
               "Hide right-click entries added by apps and Windows. Nothing is uninstalled; switch back on to "
               "restore.",
               "debloat_startup", button="Open...", ui="context"),
    # ---- debloat: cleanup
    ActionItem("junk", "Deep clean",
               "Scans update caches, Delivery Optimization files, thumbnails, logs, error reports, crash "
               "dumps and the Recycle Bin, shows sizes, and cleans only what you tick.",
               "debloat_clean", button="Scan...", ui="junk"),
    ActionItem("restart_explorer", "Restart Explorer",
               "Reloads the taskbar and File Explorer so shell tweaks show up without signing out.",
               "customise", restart_explorer, button="Restart"),
    ActionItem("latency_test", "Test latency",
               "Measures round-trip time and jitter to 1.1.1.1 (about 5 seconds). Run it before and after "
               "a tweak - the result shows the change from your previous run.",
               "network", latency_test, button="Run test"),
    ActionItem("qos_policy", "Prioritise a game's traffic",
               "Tag one program's network traffic as high priority (DSCP 46). Pick the game's .exe; you "
               "can remove policies again at any time.",
               "network", admin=True, button="Manage...", ui="qos"),
    ActionItem("restart_adapters", "Restart network adapters",
               "Applies adapter and TCP changes without rebooting. Your connection drops for a few seconds.",
               "network", restart_adapters, admin=True, button="Restart",
               confirm="Restart your network adapters now? The connection drops for a few seconds."),
    ActionItem("restore_point", "Create a restore point",
               "Recommended before applying tweaks. Lets you roll Windows back from System Restore.",
               "admin", restore_point, admin=True, button="Create",
               confirm="Create a system restore point now? This can take up to a minute."),
    ActionItem("sfc", "System File Checker (sfc /scannow)",
               "Scans Windows system files and repairs corrupted ones. Opens an admin console (UAC prompt).",
               "admin", sfc_scan, button="Open"),
    ActionItem("dism", "DISM RestoreHealth",
               "Repairs the Windows component store. Run it before SFC if SFC can't fix everything.",
               "admin", dism_repair, button="Open"),
]


def actions_for(cat: str):
    return [a for a in ACTIONS if a.category == cat]


# --------------------------------------------------------------------------- launchers
# (label, description, program, arguments, elevate)
LAUNCHERS = [
    ("Task Manager", "Processes, startup apps, performance", "taskmgr.exe", "", True),
    ("Services", "Start, stop and configure services", "mmc.exe", "services.msc", True),
    ("Registry Editor", "Browse and edit the registry", "regedit.exe", "", True),
    ("Device Manager", "Drivers and hardware", "mmc.exe", "devmgmt.msc", True),
    ("Disk Cleanup", "Windows' built-in cleaner", "cleanmgr.exe", "", True),
    ("Optimise Drives", "TRIM SSDs / defrag HDDs", "dfrgui.exe", "", True),
    ("Resource Monitor", "Live CPU, disk, network and memory", "resmon.exe", "", True),
    ("Performance Monitor", "Detailed performance counters", "perfmon.exe", "", True),
    ("Event Viewer", "System and application logs", "mmc.exe", "eventvwr.msc", True),
    ("Task Scheduler", "Scheduled and startup tasks", "mmc.exe", "taskschd.msc", True),
    ("System Configuration", "msconfig: boot and services", "msconfig.exe", "", True),
    ("Windows Features", "Turn Windows features on or off", "optionalfeatures.exe", "", True),
    ("Group Policy Editor", "Pro / Enterprise editions only", "mmc.exe", "gpedit.msc", True),
    ("Power Options", "Power plans and sleep settings", "control.exe", "powercfg.cpl", True),
    ("System Information", "Hardware and OS details", "msinfo32.exe", "", True),
    ("Startup Apps", "Settings page for startup programs", "ms-settings:startupapps", "", False),
    ("Command Prompt", "Opens elevated", "cmd.exe", "", True),
    ("PowerShell", "Opens elevated", "powershell.exe", "", True),
]


def launch(program: str, args: str, elevate: bool) -> str:
    ok = run_elevated(program, args) if elevate else shell_run(program, args)
    if not ok:
        raise RuntimeError("Could not launch it (the UAC prompt may have been declined).")
    return f"Launched {program}."
