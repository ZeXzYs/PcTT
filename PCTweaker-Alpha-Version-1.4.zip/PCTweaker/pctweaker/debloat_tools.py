"""Debloat tool backends (each returns plain data the UI turns into lists/dialogs).

  * startup manager      - enable/disable startup entries the same way Task Manager does (non-destructive)
  * scheduled tasks      - curated telemetry tasks, enable/disable
  * services viewer      - curated optional services: Auto / Manual / Off, with reset to the originals
  * context-menu cleaner - hide/show right-click entries (shell extensions via the Blocked list, verbs via LegacyDisable)
  * deep clean           - scan and delete caches/logs/dumps with sizes
  * programs scanner     - installed desktop programs, flags likely OEM/trial bloat, uninstall
  * OneDrive             - careful removal (blocked when folders are redirected into it) and reinstall
Nothing here runs until the user clicks; every change is reversible or non-destructive.
"""
import ctypes
import json
import os
import re
import struct
import time
import winreg
from ctypes import wintypes
from pathlib import Path

from .admin import powershell, run_elevated, run_hidden, shell_run
from .registry import BACKUP, SZ, VIEW, delete_value, read_value, write_value

NEEDS_ADMIN = "Needs administrator rights - restart PC Tweaker as administrator."
_H = {"HKCU": winreg.HKEY_CURRENT_USER, "HKLM": winreg.HKEY_LOCAL_MACHINE, "HKCR": winreg.HKEY_CLASSES_ROOT}
GUID = re.compile(r"^\{[0-9A-Fa-f]{8}(-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}\}$")


def _enum_values(hive, path):
    out = []
    try:
        with winreg.OpenKey(_H[hive], path, 0, winreg.KEY_READ | VIEW) as k:
            i = 0
            while True:
                try:
                    out.append(winreg.EnumValue(k, i))
                except OSError:
                    break
                i += 1
    except OSError:
        pass
    return out


def _enum_keys(hive, path):
    out = []
    try:
        with winreg.OpenKey(_H[hive], path, 0, winreg.KEY_READ | VIEW) as k:
            i = 0
            while True:
                try:
                    out.append(winreg.EnumKey(k, i))
                except OSError:
                    break
                i += 1
    except OSError:
        pass
    return out


def _rv(hive, path, name=""):
    """Raw registry value or None."""
    try:
        with winreg.OpenKey(_H[hive], path, 0, winreg.KEY_READ | VIEW) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def fmt_bytes(n) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


# ======================================================================= startup manager
APPROVED = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved"
RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"


def _startup_sources():
    appdata = os.environ.get("APPDATA", "")
    pdata = os.environ.get("PROGRAMDATA", r"C:\ProgramData")
    return [
        dict(kind="run", hive="HKCU", path=RUN, ahive="HKCU", apath=APPROVED + r"\Run", scope="You"),
        dict(kind="run", hive="HKLM", path=r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
             ahive="HKLM", apath=APPROVED + r"\Run", scope="All users"),
        dict(kind="run", hive="HKLM", path=r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
             ahive="HKLM", apath=APPROVED + r"\Run32", scope="All users (32-bit)"),
        dict(kind="folder", folder=os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup"),
             ahive="HKCU", apath=APPROVED + r"\StartupFolder", scope="You"),
        dict(kind="folder", folder=os.path.join(pdata, r"Microsoft\Windows\Start Menu\Programs\StartUp"),
             ahive="HKLM", apath=APPROVED + r"\StartupFolder", scope="All users"),
    ]


def _approved_enabled(ahive, apath, name) -> bool:
    cur = read_value(ahive, apath, name) if ahive in ("HKCU", "HKLM") else {"exists": False}
    if not cur.get("exists"):
        return True
    data = cur["data"]
    raw = bytes.fromhex(data["hex"]) if isinstance(data, dict) and "hex" in data else b""
    return not raw or raw[0] % 2 == 0           # 02/06 = enabled, 03/07 = disabled


def _startup_names(src):
    if src["kind"] == "run":
        return {n: str(d) for n, d, _ in _enum_values(src["hive"], src["path"]) if n}
    folder = src["folder"]
    if not os.path.isdir(folder):
        return {}
    return {f: os.path.join(folder, f) for f in sorted(os.listdir(folder)) if f.lower() != "desktop.ini"}


def list_startup():
    items = []
    for idx, src in enumerate(_startup_sources()):
        for name, cmd in _startup_names(src).items():
            items.append({"id": f"{idx}|{name}", "title": os.path.splitext(name)[0] if src["kind"] == "folder" else name,
                          "sub": f"{src['scope']}  ·  {cmd[:100]}",
                          "state": _approved_enabled(src["ahive"], src["apath"], name)})
    return items


def set_startup(item_id: str, enabled: bool) -> str:
    idx, _, name = item_id.partition("|")
    sources = _startup_sources()
    if not idx.isdigit() or int(idx) >= len(sources):
        raise ValueError("Unknown startup entry.")
    src = sources[int(idx)]
    if name not in _startup_names(src):
        raise ValueError("That startup entry no longer exists.")
    if enabled:
        data = b"\x02\x00\x00\x00" + b"\x00" * 8
    else:
        data = b"\x03\x00\x00\x00" + struct.pack("<Q", int((time.time() + 11644473600) * 10_000_000))
    try:
        write_value(src["ahive"], src["apath"], name, winreg.REG_BINARY, {"hex": data.hex()})
    except PermissionError:
        raise RuntimeError(NEEDS_ADMIN)
    return f"{name}: {'will start with Windows' if enabled else 'disabled at startup'}."


# ======================================================================= scheduled tasks
TASKS = [
    ("\\Microsoft\\Windows\\Application Experience\\", "Microsoft Compatibility Appraiser",
     "Collects app compatibility telemetry and sends it to Microsoft."),
    ("\\Microsoft\\Windows\\Application Experience\\", "ProgramDataUpdater",
     "Gathers program usage data for the compatibility system."),
    ("\\Microsoft\\Windows\\Application Experience\\", "StartupAppTask",
     "Scans startup entries and may show startup-app notifications."),
    ("\\Microsoft\\Windows\\Customer Experience Improvement Program\\", "Consolidator",
     "Customer Experience Improvement Program data collection."),
    ("\\Microsoft\\Windows\\Customer Experience Improvement Program\\", "UsbCeip",
     "Sends USB device usage statistics."),
    ("\\Microsoft\\Windows\\Customer Experience Improvement Program\\", "KernelCeipTask",
     "Sends kernel diagnostics statistics."),
    ("\\Microsoft\\Windows\\Autochk\\", "Proxy",
     "Collects disk-check (Autochk) data for Microsoft."),
    ("\\Microsoft\\Windows\\DiskDiagnostic\\", "Microsoft-Windows-DiskDiagnosticDataCollector",
     "Collects disk diagnostic data for Microsoft."),
    ("\\Microsoft\\Windows\\Feedback\\Siuf\\", "DmClient",
     "Feedback / telemetry client."),
    ("\\Microsoft\\Windows\\Feedback\\Siuf\\", "DmClientOnScenarioDownload",
     "Feedback / telemetry client (scenario downloads)."),
    ("\\Microsoft\\Windows\\Windows Error Reporting\\", "QueueReporting",
     "Sends queued crash reports to Microsoft."),
    ("\\Microsoft\\Windows\\Maps\\", "MapsToastTask", "Offline-maps notifications."),
    ("\\Microsoft\\Windows\\Maps\\", "MapsUpdateTask", "Offline-maps updates."),
    ("\\Microsoft\\Windows\\NetTrace\\", "GatherNetworkInfo",
     "Collects network diagnostic information."),
]
_TASK_SET = {(p, n) for p, n, _ in TASKS}


def list_tasks():
    arr = ",".join(f"@('{p}','{n}')" for p, n, _ in TASKS)
    script = ("$ErrorActionPreference='SilentlyContinue';$r=@();"
              f"foreach($t in @({arr})){{$x=Get-ScheduledTask -TaskPath $t[0] -TaskName $t[1];"
              "if($x){$r+=[pscustomobject]@{p=$t[0];n=$t[1];s=\"$($x.State)\"}}};"
              "ConvertTo-Json -InputObject @($r) -Compress")
    rc, out = powershell(script, timeout=90)
    try:
        data = json.loads(out[out.index("["):])
    except ValueError:
        raise RuntimeError(out.strip() or "Could not read scheduled tasks.")
    desc = {(p, n): d for p, n, d in TASKS}
    return [{"id": f"{t['p']}|{t['n']}", "title": t["n"], "sub": desc.get((t["p"], t["n"]), ""),
             "state": str(t.get("s")) != "Disabled"} for t in data if (t.get("p"), t.get("n")) in _TASK_SET]


def set_task(item_id: str, enabled: bool) -> str:
    path, _, name = item_id.partition("|")
    if (path, name) not in _TASK_SET:
        raise ValueError("Unknown task.")
    verb = "Enable" if enabled else "Disable"
    rc, out = powershell(f"{verb}-ScheduledTask -TaskPath '{path}' -TaskName '{name}' "
                         "-ErrorAction Stop | Out-Null", timeout=60)
    if rc != 0:
        raise RuntimeError(NEEDS_ADMIN if re.search(r"denied|access", out, re.I) else (out.strip() or "Failed."))
    return f"{name}: {'enabled' if enabled else 'disabled'}."


# ======================================================================= services viewer
# (service, title, plain-English description, caution note or "")
SERVICES = [
    ("DoSvc", "Delivery Optimization", "Shares Windows Update downloads with other PCs and uploads to them.", ""),
    ("WerSvc", "Windows Error Reporting", "Sends crash reports to Microsoft.", ""),
    ("Fax", "Fax", "Lets the PC send and receive faxes.", ""),
    ("RetailDemo", "Retail Demo", "Store-display demo mode.", ""),
    ("WMPNetworkSvc", "Windows Media Player Network Sharing", "Shares your media library over the network.", ""),
    ("PhoneSvc", "Phone Service", "Telephony state for phone-linked features.", ""),
    ("WalletService", "Wallet Service", "Backend for the Wallet app.", ""),
    ("lfsvc", "Geolocation Service", "Lets apps ask for your location.", "Maps and weather apps may stop locating you."),
    ("TabletInputService", "Touch Keyboard & Handwriting", "On-screen keyboard and pen input.", "Needed on touch screens and tablets."),
    ("stisvc", "Windows Image Acquisition", "Scanners and some cameras.", "Needed if you use a scanner."),
    ("SCardSvr", "Smart Card", "Smart-card readers.", "Needed for smart-card logins."),
    ("ScDeviceEnum", "Smart Card Device Enumeration", "Detects smart-card readers.", "Needed for smart-card logins."),
    ("SEMgrSvc", "Payments and NFC/SE Manager", "Contactless payment hardware.", ""),
    ("WbioSrvc", "Windows Biometric Service", "Fingerprint and face sign-in.", "Disabling turns off Windows Hello."),
    ("Spooler", "Print Spooler", "Printing.", "Needed if you ever print or save to PDF."),
    ("PrintNotify", "Printer Extensions & Notifications", "Printer pop-ups and extensions.", ""),
    ("WSearch", "Windows Search indexer", "Builds the search index.", "Start-menu and Explorer search get slower without it."),
    ("XblAuthManager", "Xbox Live Auth Manager", "Xbox sign-in.", "Breaks Xbox / Game Pass sign-in."),
    ("XblGameSave", "Xbox Live Game Save", "Xbox cloud saves.", "Breaks Xbox cloud saves."),
    ("XboxNetApiSvc", "Xbox Live Networking", "Xbox multiplayer networking.", "Breaks Xbox networking features."),
]
_SVC_NAMES = {s[0] for s in SERVICES}
_SC_MODE = {"auto": "auto", "manual": "demand", "off": "disabled"}


def _svc_key(name):
    return rf"SYSTEM\CurrentControlSet\Services\{name}"


def _svc_start(name):
    start = _rv("HKLM", _svc_key(name), "Start")
    return start if isinstance(start, int) else None


def _svc_mode(name):
    """Mode string usable with `sc config start=` (or None if the service doesn't exist)."""
    start = _svc_start(name)
    if start is None:
        return None
    if start == 2:
        return "delayed-auto" if _rv("HKLM", _svc_key(name), "DelayedAutostart") == 1 else "auto"
    return {3: "demand", 4: "disabled"}.get(start)


def list_services():
    items = []
    for name, title, desc, warn in SERVICES:
        mode = _svc_mode(name)
        if mode is None:
            continue
        state = {"auto": "auto", "delayed-auto": "auto", "demand": "manual", "disabled": "off"}[mode]
        items.append({"id": name, "title": f"{title}", "state": state,
                      "sub": desc + (f"  ⚠ {warn}" if warn else "")})
    return items


def _sc(name, mode):
    rc, out = run_hidden(["sc.exe", "config", name, "start=", mode])
    if rc != 0:
        raise RuntimeError(NEEDS_ADMIN if rc == 5 or "denied" in out.lower() else
                           f"Could not change {name}: {out.strip()}")


def set_service(name: str, state: str) -> str:
    if name not in _SVC_NAMES or state not in _SC_MODE:
        raise ValueError("Unknown service or mode.")
    store = BACKUP.get("svc_viewer")
    if name not in store:
        orig = _svc_mode(name)
        if orig:
            store[name] = orig
    _sc(name, _SC_MODE[state])
    BACKUP.save()
    if state == "off":
        run_hidden(["sc.exe", "stop", name])
    elif state == "auto":
        run_hidden(["sc.exe", "start", name])
    return f"{name}: set to {state}."


def reset_services() -> str:
    store = BACKUP.get("svc_viewer")
    n = 0
    for name, mode in list(store.items()):
        if name in _SVC_NAMES and mode in ("auto", "delayed-auto", "demand", "disabled"):
            _sc(name, mode)
            if mode in ("auto", "delayed-auto"):
                run_hidden(["sc.exe", "start", name])
            n += 1
    BACKUP.drop("svc_viewer")
    return f"Restored {n} service(s) to their original start type."


# ======================================================================= context-menu cleaner
LOCS = [("All files", "*"), ("Folders", "Directory"), ("Folder background", r"Directory\Background"),
        ("Drives", "Drive"), ("Everything", "AllFilesystemObjects")]
BLOCKED = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked"


def _clsid_name(clsid):
    v = _rv("HKCR", rf"CLSID\{clsid}", "")
    return v if isinstance(v, str) and v else None


def _verb_title(path, verb):
    for value in ("MUIVerb", ""):
        v = _rv("HKCR", path, value)
        if isinstance(v, str) and v and not v.startswith("@"):
            return v.replace("&", "")
    return verb


def list_context():
    blocked = {n.lower() for n, _, _ in _enum_values("HKLM", BLOCKED)}
    items, seen = [], set()
    for label, loc in LOCS:
        base = rf"{loc}\shellex\ContextMenuHandlers"
        for sub in _enum_keys("HKCR", base):
            default = _rv("HKCR", base + "\\" + sub, "")
            clsid = default if isinstance(default, str) and GUID.match(default) else (sub if GUID.match(sub) else None)
            if not clsid or clsid.lower() in seen:
                continue
            seen.add(clsid.lower())
            title = sub if not GUID.match(sub) else (_clsid_name(clsid) or clsid)
            items.append({"id": f"h|{clsid}", "title": title, "sub": f"Shell extension  ·  {label}",
                          "state": clsid.lower() not in blocked})
        vbase = rf"{loc}\shell"
        for verb in _enum_keys("HKCR", vbase):
            vp = vbase + "\\" + verb
            hidden = _rv("HKCR", vp, "LegacyDisable") is not None
            items.append({"id": f"v|{loc}|{verb}", "title": _verb_title(vp, verb),
                          "sub": f"Menu item  ·  {label}", "state": not hidden})
    return items


def set_context(item_id: str, show: bool) -> str:
    kind, _, rest = item_id.partition("|")
    try:
        if kind == "h":
            if not GUID.match(rest):
                raise ValueError("Bad handler id.")
            if show:
                delete_value("HKLM", BLOCKED, rest)
            else:
                write_value("HKLM", BLOCKED, rest, SZ, "")
            return f"{'Shown' if show else 'Hidden'}. Restart Explorer to apply."
        if kind == "v":
            loc, _, verb = rest.partition("|")
            if loc not in {l for _, l in LOCS} or verb not in _enum_keys("HKCR", rf"{loc}\shell"):
                raise ValueError("Unknown menu item.")
            with winreg.OpenKey(_H["HKCR"], rf"{loc}\shell\{verb}", 0, winreg.KEY_SET_VALUE | VIEW) as k:
                if show:
                    try:
                        winreg.DeleteValue(k, "LegacyDisable")
                    except OSError:
                        pass
                else:
                    winreg.SetValueEx(k, "LegacyDisable", 0, winreg.REG_SZ, "")
            return f"{'Shown' if show else 'Hidden'}. Restart Explorer to apply."
    except PermissionError:
        raise RuntimeError(NEEDS_ADMIN)
    raise ValueError("Unknown entry.")


# ======================================================================= deep clean
class _RBInfo(ctypes.Structure):
    _pack_ = 1
    _fields_ = [("cbSize", wintypes.DWORD), ("i64Size", ctypes.c_longlong), ("i64NumItems", ctypes.c_longlong)]


def _recycle_size() -> int:
    try:
        info = _RBInfo()
        info.cbSize = ctypes.sizeof(info)
        ctypes.windll.shell32.SHQueryRecycleBinW(None, ctypes.byref(info))
        return int(info.i64Size)
    except Exception:
        return 0


def _junk_defs():
    e = os.environ
    win, local = e.get("WINDIR", r"C:\Windows"), e.get("LOCALAPPDATA", "")
    pdata = e.get("PROGRAMDATA", r"C:\ProgramData")
    wer = os.path.join(pdata, "Microsoft", "Windows", "WER")
    return [
        dict(id="wu", name="Windows Update download cache", default=True, admin=True, services=["wuauserv", "bits"],
             desc="Update files Windows already installed. Anything still needed is downloaded again.",
             paths=[(os.path.join(win, "SoftwareDistribution", "Download"), None)]),
        dict(id="do", name="Delivery Optimization cache", default=True, admin=True,
             desc="Cached update pieces shared with other PCs.",
             paths=[(os.path.join(win, "ServiceProfiles", "NetworkService", "AppData", "Local", "Microsoft",
                                  "Windows", "DeliveryOptimization", "Cache"), None)]),
        dict(id="thumbs", name="Thumbnail & icon cache", default=True, admin=False,
             desc="Explorer rebuilds these as you browse (files in use are skipped).",
             paths=[(os.path.join(local, "Microsoft", "Windows", "Explorer"), ("thumbcache_*.db", "iconcache_*.db"))]),
        dict(id="logs", name="Windows log files", default=True, admin=True,
             desc="Servicing and DISM logs.",
             paths=[(os.path.join(win, "Logs", "CBS"), ("*.log", "*.cab")), (os.path.join(win, "Logs", "DISM"), ("*.log",))]),
        dict(id="wer", name="Error reports", default=True, admin=True,
             desc="Queued and archived crash reports.",
             paths=[(os.path.join(wer, "ReportArchive"), None), (os.path.join(wer, "ReportQueue"), None),
                    (os.path.join(wer, "Temp"), None)]),
        dict(id="dumps", name="Crash dumps", default=False, admin=True,
             desc="Memory dumps from past crashes. Keep them if you are debugging a crash.",
             paths=[(os.path.join(win, "Minidump"), None), (os.path.join(local, "CrashDumps"), None),
                    (win, ("MEMORY.DMP",))]),
        dict(id="dx", name="DirectX shader cache", default=False, admin=False,
             desc="Games rebuild it, so the first launch afterwards may stutter.",
             paths=[(os.path.join(local, "D3DSCache"), None)]),
        dict(id="recycle", name="Recycle Bin", default=False, admin=False, special="recycle",
             desc="Permanently empties the Recycle Bin.", paths=[]),
    ]


def _iter_files(root, patterns):
    if not os.path.isdir(root):
        return
    if patterns:
        for pat in patterns:
            for p in Path(root).glob(pat):
                if p.is_file():
                    yield str(p)
    else:
        for r, _, fs in os.walk(root):
            for f in fs:
                yield os.path.join(r, f)


def _size(entry) -> int:
    if entry.get("special") == "recycle":
        return _recycle_size()
    total = 0
    for root, patterns in entry["paths"]:
        for f in _iter_files(root, patterns):
            try:
                total += os.path.getsize(f)
            except OSError:
                pass
    return total


def scan_junk():
    return [{"id": e["id"], "name": e["name"], "desc": e["desc"], "default": e["default"],
             "admin": e["admin"], "size": _size(e)} for e in _junk_defs()]


def _running_services(names):
    rc, out = powershell("(Get-Service -Name " + ",".join(names) + " -ErrorAction SilentlyContinue | "
                         "Where-Object { $_.Status -eq 'Running' } | ForEach-Object { $_.Name }) -join ','", timeout=60)
    return [n for n in out.strip().split(",") if n in names]


def clean_junk(ids) -> str:
    freed, skipped = 0, 0
    for e in _junk_defs():
        if e["id"] not in ids:
            continue
        if e.get("special") == "recycle":
            freed += _recycle_size()
            try:
                ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 0x7)
            except Exception:
                skipped += 1
            continue
        stopped = _running_services(e["services"]) if e.get("services") else []
        for n in stopped:
            powershell(f"Stop-Service -Name {n} -Force -ErrorAction SilentlyContinue", timeout=60)
        try:
            for root, patterns in e["paths"]:
                for f in _iter_files(root, patterns):
                    try:
                        size = os.path.getsize(f)
                        os.remove(f)
                        freed += size
                    except OSError:
                        skipped += 1
                if not patterns and os.path.isdir(root):
                    for r, dirs, _ in os.walk(root, topdown=False):
                        for d in dirs:
                            try:
                                os.rmdir(os.path.join(r, d))
                            except OSError:
                                pass
        finally:
            for n in stopped:
                powershell(f"Start-Service -Name {n} -ErrorAction SilentlyContinue", timeout=60)
    return f"Deep clean finished: freed {fmt_bytes(freed)} ({skipped} item(s) in use were skipped)."


# ======================================================================= programs scanner
_BLOAT = [(re.compile(p, re.I), label) for p, label in [
    (r"mcafee", "Trial security software"), (r"norton", "Trial security software"),
    (r"wildtangent", "Bundled games"), (r"amazon (assistant|music)", "Bundled shopping / media"),
    (r"hp (support assistant|documentation|jumpstart|wolf security)", "HP preinstalled helper"),
    (r"dell (supportassist|digital delivery|customer connect|optimizer)", "Dell preinstalled helper"),
    (r"lenovo (welcome|now)\b", "Lenovo preinstalled helper"),
    (r"acer (care center|collection|portal|jumpstart)", "Acer preinstalled helper"),
    (r"asus giftbox", "ASUS preinstalled helper"),
    (r"cyberlink (powerdvd|youcam|media suite)", "Bundled trial software"),
    (r"corel (paintshop|videostudio)", "Bundled trial software"),
    (r"booking\.com", "Bundled shopping / media"),
]]
_UNINSTALL_BASES = [
    ("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ("HKLM", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
    ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
]


def list_programs():
    seen, out = set(), []
    for hive, base in _UNINSTALL_BASES:
        for sub in _enum_keys(hive, base):
            vals = {n: d for n, d, _ in _enum_values(hive, base + "\\" + sub)}
            name, un = vals.get("DisplayName"), vals.get("UninstallString")
            if not name or not un or vals.get("SystemComponent") == 1 or vals.get("ParentKeyName"):
                continue
            key = (name, vals.get("DisplayVersion"))
            if key in seen:
                continue
            seen.add(key)
            pub = str(vals.get("Publisher") or "")
            flag = next((lbl for rx, lbl in _BLOAT if rx.search(name) or rx.search(pub)), None)
            kb = vals.get("EstimatedSize")
            out.append({"id": f"{hive}|{base}|{sub}", "name": str(name), "publisher": pub,
                        "size": (kb * 1024) if isinstance(kb, int) else 0, "flag": flag})
    return sorted(out, key=lambda x: (x["flag"] is None, x["name"].lower()))


def uninstall_program(item_id: str) -> str:
    hive, _, rest = item_id.partition("|")
    base, _, sub = rest.rpartition("|")
    allowed = set(_UNINSTALL_BASES)
    if (hive, base) not in allowed or not sub:
        raise ValueError("Unknown program.")
    un = _rv(hive, base + "\\" + sub, "UninstallString")
    name = _rv(hive, base + "\\" + sub, "DisplayName") or sub
    if not isinstance(un, str) or not un.strip():
        raise RuntimeError("This program has no uninstaller.")
    if re.match(r"(?i)^\s*msiexec", un):
        un = re.sub(r"(?i)/I(?=\s*\{)", "/X", un)          # make sure MSI entries uninstall, not 'modify'
    params = f'/c "{un}"'
    # Per-user (HKCU) entries are user-writable, so they are never launched elevated.
    ok = run_elevated("cmd.exe", params, 0) if hive == "HKLM" else shell_run("cmd.exe", params, "open", 0)
    if not ok:
        raise RuntimeError("Could not start the uninstaller (was the UAC prompt declined?).")
    return f"Started the uninstaller for {name}."


# ======================================================================= OneDrive
SHELL_FOLDERS = r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"


def _onedrive_setup():
    win = os.environ.get("SystemRoot", r"C:\Windows")
    for sub in ("SysWOW64", "System32"):
        p = os.path.join(win, sub, "OneDriveSetup.exe")
        if os.path.exists(p):
            return p
    return None


def onedrive_redirected():
    names = {"Desktop": "Desktop", "Personal": "Documents", "My Pictures": "Pictures"}
    found = []
    for key, label in names.items():
        v = _rv("HKCU", SHELL_FOLDERS, key)
        if isinstance(v, str) and "onedrive" in v.lower():
            found.append(label)
    return found


def remove_onedrive() -> str:
    red = onedrive_redirected()
    if red:
        raise RuntimeError(
            "Your " + ", ".join(red) + " folder(s) are backed up to OneDrive, so removing it now could make "
            "them look empty. In OneDrive: Settings > Sync and backup > Manage backup > stop backing up "
            "those folders, then try again.")
    setup = _onedrive_setup()
    if not setup:
        raise RuntimeError("OneDrive doesn't appear to be installed.")
    run_hidden(["taskkill.exe", "/f", "/im", "OneDrive.exe"])
    rc, out = run_hidden([setup, "/uninstall"], timeout=240)
    return "OneDrive was uninstalled. Files already in your OneDrive folder were left on disk."


def reinstall_onedrive() -> str:
    setup = _onedrive_setup()
    ok = shell_run(setup, "") if setup else shell_run("https://www.microsoft.com/microsoft-365/onedrive/download")
    if not ok:
        raise RuntimeError("Could not start the OneDrive installer.")
    return "OneDrive setup started." if setup else "Opened the OneDrive download page."
