"""Built-in app and optional-feature removal (curated lists only).

Protected on purpose and never offered: File Explorer / the Windows shell, Microsoft Edge,
Microsoft Store, Settings, Windows Security, and other components Windows needs to run and update.
"""
import json
import re

from .admin import powershell

GROUP_REC = "Recommended - Microsoft clutter"
GROUP_DAILY = "Everyday apps - keep the ones you use"
GROUP_SPONSORED = "Preinstalled third-party apps"
GROUP_GAMING = "Xbox & gaming"
GROUPS = [GROUP_REC, GROUP_DAILY, GROUP_SPONSORED, GROUP_GAMING]

# (package name, label, group)
APPS = [
    ("Clipchamp.Clipchamp", "Clipchamp video editor", GROUP_REC),
    ("Microsoft.BingNews", "Microsoft News", GROUP_REC),
    ("Microsoft.BingWeather", "Weather", GROUP_REC),
    ("Microsoft.BingSearch", "Bing Search", GROUP_REC),
    ("Microsoft.GetHelp", "Get Help", GROUP_REC),
    ("Microsoft.Getstarted", "Tips", GROUP_REC),
    ("Microsoft.MicrosoftOfficeHub", "Microsoft 365 hub", GROUP_REC),
    ("Microsoft.MicrosoftSolitaireCollection", "Solitaire Collection", GROUP_REC),
    ("Microsoft.People", "People", GROUP_REC),
    ("Microsoft.PowerAutomateDesktop", "Power Automate", GROUP_REC),
    ("Microsoft.Todos", "Microsoft To Do", GROUP_REC),
    ("Microsoft.WindowsFeedbackHub", "Feedback Hub", GROUP_REC),
    ("Microsoft.WindowsMaps", "Maps", GROUP_REC),
    ("Microsoft.MixedReality.Portal", "Mixed Reality Portal", GROUP_REC),
    ("Microsoft.3DBuilder", "3D Builder", GROUP_REC),
    ("Microsoft.Microsoft3DViewer", "3D Viewer", GROUP_REC),
    ("Microsoft.Print3D", "Print 3D", GROUP_REC),
    ("Microsoft.SkypeApp", "Skype", GROUP_REC),
    ("MicrosoftTeams", "Microsoft Teams (personal)", GROUP_REC),
    ("Microsoft.549981C3F5F10", "Cortana", GROUP_REC),
    ("Microsoft.Whiteboard", "Whiteboard", GROUP_REC),
    ("MicrosoftCorporationII.MicrosoftFamily", "Microsoft Family", GROUP_REC),

    ("Microsoft.WindowsCalculator", "Calculator", GROUP_DAILY),
    ("Microsoft.Windows.Photos", "Photos", GROUP_DAILY),
    ("Microsoft.WindowsCamera", "Camera", GROUP_DAILY),
    ("Microsoft.WindowsAlarms", "Alarms & Clock", GROUP_DAILY),
    ("Microsoft.WindowsSoundRecorder", "Voice Recorder", GROUP_DAILY),
    ("microsoft.windowscommunicationsapps", "Mail & Calendar", GROUP_DAILY),
    ("Microsoft.Paint", "Paint", GROUP_DAILY),
    ("Microsoft.WindowsNotepad", "Notepad", GROUP_DAILY),
    ("Microsoft.ScreenSketch", "Snipping Tool", GROUP_DAILY),
    ("Microsoft.MicrosoftStickyNotes", "Sticky Notes", GROUP_DAILY),
    ("Microsoft.ZuneMusic", "Media Player / Groove Music", GROUP_DAILY),
    ("Microsoft.ZuneVideo", "Movies & TV", GROUP_DAILY),
    ("Microsoft.YourPhone", "Phone Link", GROUP_DAILY),
    ("Microsoft.OutlookForWindows", "Outlook (new)", GROUP_DAILY),
    ("Microsoft.Office.OneNote", "OneNote", GROUP_DAILY),
    ("MicrosoftCorporationII.QuickAssist", "Quick Assist", GROUP_DAILY),
    ("Microsoft.Windows.DevHome", "Dev Home", GROUP_DAILY),

    ("SpotifyAB.SpotifyMusic", "Spotify", GROUP_SPONSORED),
    ("Disney.37853FC22B2CE", "Disney+", GROUP_SPONSORED),
    ("AmazonVideo.PrimeVideo", "Prime Video", GROUP_SPONSORED),
    ("4DF9E0F8.Netflix", "Netflix", GROUP_SPONSORED),
    ("BytedancePte.Ltd.TikTok", "TikTok", GROUP_SPONSORED),
    ("5319275A.WhatsAppDesktop", "WhatsApp", GROUP_SPONSORED),
    ("Facebook.Facebook", "Facebook", GROUP_SPONSORED),
    ("Facebook.InstagramBeta", "Instagram", GROUP_SPONSORED),
    ("king.com.CandyCrushSaga", "Candy Crush Saga", GROUP_SPONSORED),
    ("king.com.CandyCrushSodaSaga", "Candy Crush Soda Saga", GROUP_SPONSORED),

    ("Microsoft.GamingApp", "Xbox app", GROUP_GAMING),
    ("Microsoft.XboxGamingOverlay", "Xbox Game Bar", GROUP_GAMING),
]

# (feature name, label, description)
FEATURES = [
    ("Internet-Explorer-Optional-amd64", "Internet Explorer", "The legacy browser. Microsoft Edge is not affected."),
    ("WindowsMediaPlayer", "Windows Media Player (legacy)", "The old media player, separate from the new Media Player app."),
    ("Printing-XPSServices-Features", "XPS Services", "XPS document printing and viewing."),
    ("FaxServicesClientPackage", "Windows Fax and Scan", "Fax and scanning client."),
    ("WorkFolders-Client", "Work Folders", "Corporate file-sync client."),
]

_NAME_OK = re.compile(r"^[A-Za-z0-9._-]+$")


def recommended_names():
    return [p for p, _, g in APPS if g == GROUP_REC]


def non_essential_names():
    return [p for p, _, g in APPS if g != GROUP_GAMING]


def installed_apps():
    """Set of installed package names (all users), or None if it could not be read."""
    rc, out = powershell(
        "ConvertTo-Json -InputObject @(Get-AppxPackage -AllUsers | Select-Object -ExpandProperty Name "
        "| Sort-Object -Unique) -Compress", timeout=120)
    try:
        return {str(n) for n in json.loads(out[out.index("["):])}
    except ValueError:
        return None


def enabled_features():
    """Set of enabled optional-feature names (needs admin), or None."""
    rc, out = powershell(
        "ConvertTo-Json -InputObject @(Get-WindowsOptionalFeature -Online | Where-Object "
        "{ $_.State -eq 'Enabled' } | Select-Object -ExpandProperty FeatureName) -Compress", timeout=180)
    try:
        return {str(n) for n in json.loads(out[out.index("["):])}
    except ValueError:
        return None


def _parse(out):
    res = {"removed": [], "kept": [], "absent": []}
    for line in out.splitlines():
        tag, _, name = line.strip().partition(":")
        key = {"REMOVED": "removed", "KEPT": "kept", "ABSENT": "absent"}.get(tag)
        if key:
            res[key].append(name)
    return res


def remove_apps(package_names):
    """Remove the given packages. Returns {'removed': [...], 'kept': [...], 'absent': [...]}."""
    known = {a[0] for a in APPS}
    names = [n for n in package_names if n in known and _NAME_OK.match(n)]
    if not names:
        return {"removed": [], "kept": [], "absent": []}
    arr = ",".join(f"'{n}'" for n in names)
    script = (
        "$ErrorActionPreference='SilentlyContinue';"
        f"foreach($n in @({arr})){{"
        "$had=[bool](Get-AppxPackage -AllUsers -Name $n);"
        "if($had){Get-AppxPackage -AllUsers -Name $n | Remove-AppxPackage -AllUsers};"
        "Get-AppxProvisionedPackage -Online | Where-Object {$_.DisplayName -eq $n} | "
        "Remove-AppxProvisionedPackage -Online | Out-Null;"
        "if(-not $had){Write-Output \"ABSENT:$n\"}"
        "elseif(Get-AppxPackage -AllUsers -Name $n){Write-Output \"KEPT:$n\"}"
        "else{Write-Output \"REMOVED:$n\"}}"
    )
    rc, out = powershell(script, timeout=900)
    res = _parse(out)
    if not any(res.values()):
        raise RuntimeError(out.strip() or "PowerShell returned no result.")
    return res


def remove_features(feature_names):
    """Disable the given optional Windows features (no restart is forced)."""
    known = {f[0] for f in FEATURES}
    names = [n for n in feature_names if n in known and _NAME_OK.match(n)]
    if not names:
        return {"removed": [], "kept": [], "absent": []}
    arr = ",".join(f"'{n}'" for n in names)
    script = (
        f"foreach($n in @({arr})){{"
        "try{Disable-WindowsOptionalFeature -Online -FeatureName $n -NoRestart -ErrorAction Stop | Out-Null;"
        "Write-Output \"REMOVED:$n\"}catch{Write-Output \"KEPT:$n\"}}"
    )
    rc, out = powershell(script, timeout=900)
    res = _parse(out)
    if not any(res.values()):
        raise RuntimeError(out.strip() or "PowerShell returned no result.")
    return res


def remove_recommended() -> str:
    """One click: remove every installed app from the recommended (clutter) group."""
    inst = installed_apps()
    names = [n for n in recommended_names() if inst is None or n in inst]
    if not names:
        return "Nothing to remove - the recommended clutter apps aren't installed."
    res = remove_apps(names)
    msg = f"Removed {len(res['removed'])} app(s)"
    if res["kept"]:
        msg += f", {len(res['kept'])} couldn't be removed"
    return msg + ". Reinstall any of them from the Microsoft Store."
