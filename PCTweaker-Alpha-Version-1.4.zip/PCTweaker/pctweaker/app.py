"""PC Tweaker main window (customtkinter)."""
import os
import platform
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk
import psutil

from . import __version__, helpers
from .admin import is_admin, relaunch_as_admin, run_elevated
from .config import APP_NAME, TOOLS_DIR, Settings, resource_path
from . import debloat_tools as dt
from .debloat import (APPS, FEATURES, GROUP_DAILY, GROUP_REC, GROUP_SPONSORED, GROUPS,
                      enabled_features, installed_apps, remove_apps, remove_features)
from .fancontrol import CURVE_TEMPS, CPU_LIMIT, GPU_LIMIT, MIN_PCT, FanController
from .fps import PresentMonReader
from .network import add_qos_policy, list_qos_policies, remove_qos_policy
from .overlay import Overlay
from .sensors import Sensors
from .tools import LAUNCHERS, actions_for, launch
from .tweaks import by_category

BG = "#0e1117"
SIDEBAR = "#131722"
CARD = "#181d2a"
CARD_HOVER = "#212840"
LINE = "#262d3f"
TEXT = "#e8ecf4"
MUTED = "#8891a7"
ACCENT = "#4f8cff"
ACCENT_SOFT = "#1d2943"
OK = "#34d399"
WARN = "#fbbf24"
BAD = "#f87171"

METRIC_LABELS = [
    ("fps", "FPS"), ("cpu_usage", "CPU usage"), ("cpu_temp", "CPU temperature"),
    ("gpu_usage", "GPU usage"), ("gpu_temp", "GPU temperature"), ("vram", "GPU memory"),
    ("ram", "RAM usage"), ("fans", "Fan speeds"), ("refresh", "Refresh rate"),
]


def windows_name() -> str:
    try:
        build = sys.getwindowsversion().build
        return "Windows 11" if build >= 22000 else "Windows 10"
    except Exception:
        return platform.system()


# ======================================================================= shared widgets
class ItemRow(ctk.CTkFrame):
    """One tweak (switch) or one action (button)."""

    def __init__(self, master, app, item):
        super().__init__(master, fg_color=CARD, corner_radius=10)
        self.app, self.item = app, item
        self.grid_columnconfigure(0, weight=1)
        text = ctk.CTkFrame(self, fg_color="transparent")
        text.grid(row=0, column=0, sticky="w", padx=(16, 8), pady=12)
        top = ctk.CTkFrame(text, fg_color="transparent")
        top.pack(anchor="w")
        ctk.CTkLabel(top, text=item.name, font=app.f_bold, text_color=TEXT).pack(side="left")
        if item.admin:
            self._badge(top, "ADMIN", WARN)
        if getattr(item, "reboot", False):
            self._badge(top, "REBOOT", MUTED)
        ctk.CTkLabel(text, text=item.desc, font=app.f_small, text_color=MUTED,
                     wraplength=540, justify="left").pack(anchor="w", pady=(3, 0))
        if item.kind == "toggle":
            self.switch = ctk.CTkSwitch(self, text="", width=44, command=self._toggled,
                                        progress_color=ACCENT, fg_color="#2c3447")
            self.switch.grid(row=0, column=1, padx=(8, 18))
        else:
            self.button = ctk.CTkButton(self, text=item.button, width=120, height=32,
                                        command=self._run, fg_color=ACCENT_SOFT,
                                        hover_color="#27365a", text_color=TEXT)
            self.button.grid(row=0, column=1, padx=(8, 16))

    @staticmethod
    def _badge(parent, text, color):
        ctk.CTkLabel(parent, text=f" {text} ", height=18, corner_radius=5, fg_color="#262d3d",
                     text_color=color, font=ctk.CTkFont("Segoe UI", 10, "bold")
                     ).pack(side="left", padx=(8, 0))

    def set_state(self, applied: bool):
        if applied:
            self.switch.select()
        else:
            self.switch.deselect()

    def _toggled(self):
        t, want = self.item, bool(self.switch.get())
        if t.admin and not is_admin():
            self.set_state(not want)
            self.app.need_admin(t.name)
            return
        if t.confirm and not messagebox.askyesno(APP_NAME, t.confirm, parent=self.app):
            self.set_state(not want)
            return
        self.switch.configure(state="disabled")

        def work():
            msg = t.apply() if want else t.revert()
            return msg, t.is_applied()

        def done(res, err):
            self.switch.configure(state="normal")
            if err:
                self.set_state(not want)
                self.app.say(f"{t.name}: {err}", "bad")
            else:
                self.set_state(res[1])
                self.app.say(res[0], "ok")

        self.app.run_bg(work, done)

    def _run(self):
        it = self.item
        if it.admin and not is_admin():
            self.app.need_admin(it.name)
            return
        if it.ui == "qos":
            QosDialog(self.app)
            return
        if it.ui:
            open_dialog(self.app, it.ui)
            return
        if it.confirm and not messagebox.askyesno(APP_NAME, it.confirm, parent=self.app):
            return
        self.button.configure(state="disabled", text="Working...")

        def done(res, err):
            self.button.configure(state="normal", text=it.button)
            self.app.say(f"{it.name}: {err}" if err else res, "bad" if err else "ok")

        self.app.run_bg(it.run, done)


class ListPage(ctk.CTkFrame):
    def __init__(self, app, title, subtitle, sections, banner=None):
        super().__init__(app.content, fg_color="transparent")
        self.rows = []
        ctk.CTkLabel(self, text=title, font=app.f_title, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(self, text=subtitle, font=app.f_small, text_color=MUTED).pack(anchor="w", pady=(2, 10))
        if banner:
            bar = ctk.CTkFrame(self, fg_color=ACCENT_SOFT, corner_radius=10)
            bar.pack(fill="x", pady=(0, 6))
            ctk.CTkLabel(bar, text=banner[0], font=app.f_small, text_color=TEXT,
                         wraplength=560, justify="left").pack(side="left", padx=16, pady=10)
            ctk.CTkButton(bar, text=banner[1], width=150, height=30, command=banner[2],
                          fg_color=ACCENT, hover_color="#3d79e8").pack(side="right", padx=12)
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True)
        for heading, items in sections:
            if heading:
                ctk.CTkLabel(scroll, text=heading.upper(), font=ctk.CTkFont("Segoe UI", 11, "bold"),
                             text_color=MUTED).pack(anchor="w", pady=(14, 4))
            for it in items:
                row = ItemRow(scroll, app, it)
                row.pack(fill="x", pady=3)
                if it.kind == "toggle":
                    self.rows.append(row)


class BaseDialog(ctk.CTkToplevel):
    """Modal-ish helper window with a title, intro text and a scrollable body."""

    def __init__(self, app, title, intro, size="560x680"):
        super().__init__(app)
        self.app = app
        self.title(title)
        self.geometry(size)
        self.configure(fg_color=BG)
        self.transient(app)
        self.after(200, self._modal)
        ctk.CTkLabel(self, text=title, font=app.f_title, text_color=TEXT).pack(anchor="w", padx=20, pady=(18, 0))
        ctk.CTkLabel(self, text=intro, font=app.f_small, text_color=MUTED, wraplength=500, justify="left"
                     ).pack(anchor="w", padx=20, pady=(2, 8))
        self.top = ctk.CTkFrame(self, fg_color="transparent")
        self.top.pack(fill="x", padx=20)
        self.box = ctk.CTkScrollableFrame(self, fg_color=CARD)
        self.box.pack(fill="both", expand=True, padx=20, pady=6)
        self.footer = ctk.CTkFrame(self, fg_color="transparent")
        self.footer.pack(fill="x", padx=20, pady=(4, 14))
        ctk.CTkButton(self.footer, text="Close", width=90, fg_color="transparent", border_width=1,
                      border_color=LINE, command=self.destroy).pack(side="right")

    def _modal(self):
        try:
            self.grab_set()
            self.focus()
        except tk.TclError:
            pass

    def clear(self):
        for w in self.box.winfo_children():
            w.destroy()

    def message(self, text):
        self.clear()
        ctk.CTkLabel(self.box, text=text, text_color=MUTED, font=self.app.f_small, wraplength=460,
                     justify="left").pack(anchor="w", padx=10, pady=12)


class AppxDialog(BaseDialog):
    """Pick apps and Windows features to remove. Only things that are installed are listed."""

    def __init__(self, app):
        super().__init__(app, "Remove apps & features",
                         "Only items installed on this PC are listed. Apps can be reinstalled from the Microsoft "
                         "Store. Protected and never offered: File Explorer, Microsoft Edge, Microsoft Store, "
                         "Settings and Windows Security.", "560x720")
        self.checks = []        # (kind, id, group, widget)
        bar = ctk.CTkFrame(self.top, fg_color="transparent")
        bar.pack(fill="x")
        for text, cmd in (("Recommended", self._recommended), ("All non-essential", self._all), ("None", self._none)):
            ctk.CTkButton(bar, text=text, width=120 if len(text) > 6 else 70, height=28, fg_color=ACCENT_SOFT,
                          hover_color="#27365a", command=cmd).pack(side="left", padx=(0, 6))
        ctk.CTkButton(self.footer, text="Remove selected", width=140, fg_color="#c0392b", hover_color="#a93226",
                      command=self._go).pack(side="right", padx=8)
        self.message("Scanning installed apps and Windows features...")
        app.run_bg(lambda: (installed_apps(), enabled_features()), self._built)

    def _built(self, res, err):
        if not self.winfo_exists():
            return
        inst, feats = res or (None, None)
        self.clear()
        self.checks = []
        for group in GROUPS:
            apps = [(p, l) for p, l, g in APPS if g == group and (inst is None or p in inst)]
            if not apps:
                continue
            ctk.CTkLabel(self.box, text=group.upper(), font=ctk.CTkFont("Segoe UI", 11, "bold"),
                         text_color=MUTED).pack(anchor="w", padx=10, pady=(10, 2))
            for pkg, label in apps:
                self._add("app", pkg, label, group)
        ctk.CTkLabel(self.box, text="WINDOWS FEATURES", font=ctk.CTkFont("Segoe UI", 11, "bold"),
                     text_color=MUTED).pack(anchor="w", padx=10, pady=(14, 2))
        if feats is None:
            ctk.CTkLabel(self.box, text="Windows features couldn't be listed (needs administrator).",
                         font=self.app.f_small, text_color=MUTED).pack(anchor="w", padx=10)
        shown = [f for f in FEATURES if feats is not None and f[0] in feats]
        for name, label, desc in shown:
            self._add("feature", name, f"{label}  -  {desc}", "Windows features")
        if feats is not None and not shown:
            ctk.CTkLabel(self.box, text="None of the removable features are enabled.", font=self.app.f_small,
                         text_color=MUTED).pack(anchor="w", padx=10)
        if not self.checks:
            self.message("Nothing removable was found - these apps and features are already gone.")
        self._recommended()

    def _add(self, kind, ident, label, group):
        cb = ctk.CTkCheckBox(self.box, text=label, checkbox_width=20, checkbox_height=20, fg_color=ACCENT,
                             hover_color="#3d79e8", font=self.app.f_small)
        cb.pack(anchor="w", padx=14, pady=3)
        self.checks.append((kind, ident, group, cb))

    def _tick(self, groups):
        for kind, ident, group, cb in self.checks:
            cb.select() if group in groups else cb.deselect()

    def _recommended(self):
        self._tick({GROUP_REC})

    def _all(self):
        self._tick({GROUP_REC, GROUP_DAILY, GROUP_SPONSORED, "Windows features"})

    def _none(self):
        self._tick(set())

    def _go(self):
        apps = [i for k, i, _, cb in self.checks if k == "app" and cb.get()]
        feats = [i for k, i, _, cb in self.checks if k == "feature" and cb.get()]
        if not apps and not feats:
            return
        if not messagebox.askyesno(APP_NAME, f"Remove {len(apps)} app(s) and {len(feats)} Windows feature(s)?",
                                   parent=self):
            return
        self.destroy()
        app = self.app
        app.say("Removing - this can take a few minutes...", "warn")

        def work():
            res = remove_apps(apps) if apps else {"removed": [], "kept": [], "absent": []}
            fres = remove_features(feats) if feats else {"removed": [], "kept": [], "absent": []}
            return res, fres

        def done(res, err):
            if err:
                app.say(f"Remove: {err}", "bad")
                return
            (a, f) = res
            msg = f"Removed {len(a['removed'])} app(s) and {len(f['removed'])} feature(s)"
            kept = len(a["kept"]) + len(f["kept"])
            if kept:
                msg += f"; {kept} couldn't be removed"
            app.say(msg + ".", "ok")

        app.run_bg(work, done)


class ToggleListDialog(BaseDialog):
    """Generic list of switches (or Auto/Manual/Off selectors) loaded in the background."""

    def __init__(self, app, title, intro, loader, setter, segments=None, reset=None, filterable=False):
        super().__init__(app, title, intro, "640x700")
        self.loader, self.setter, self.segments, self.rows = loader, setter, segments, []
        if filterable:
            self.search = ctk.CTkEntry(self.top, placeholder_text="Filter...", height=30)
            self.search.pack(fill="x")
            self.search.bind("<KeyRelease>", lambda e: self._filter())
        if reset:
            ctk.CTkButton(self.footer, text="Restore originals", width=140, fg_color=ACCENT_SOFT,
                          hover_color="#27365a", command=lambda: self._reset(reset)).pack(side="left")
        self.message("Loading...")
        app.run_bg(loader, self._built)

    def _built(self, items, err):
        if not self.winfo_exists():
            return
        if err:
            self.message(f"Could not load the list: {err}")
            return
        if not items:
            self.message("Nothing found.")
            return
        self.clear()
        self.rows = []
        for it in items:
            row = ctk.CTkFrame(self.box, fg_color="transparent")
            row.pack(fill="x", padx=6, pady=3)
            text = ctk.CTkFrame(row, fg_color="transparent")
            text.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(text, text=it["title"], font=self.app.f_bold, text_color=TEXT, anchor="w").pack(anchor="w")
            ctk.CTkLabel(text, text=it["sub"], font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, anchor="w",
                         wraplength=360, justify="left").pack(anchor="w")
            if self.segments:
                ctl = ctk.CTkSegmentedButton(row, values=list(self.segments), selected_color=ACCENT, width=190,
                                             command=lambda v, it=it: self._change(it, v))
                ctl.set(self._seg_label(it["state"]))
            else:
                ctl = ctk.CTkSwitch(row, text="", width=44, progress_color=ACCENT, fg_color="#2c3447")
                ctl.configure(command=lambda it=it, c=ctl: self._change(it, bool(c.get())))
                ctl.select() if it["state"] else ctl.deselect()
            ctl.pack(side="right", padx=4)
            self.rows.append({"item": it, "row": row, "ctl": ctl, "text": (it["title"] + " " + it["sub"]).lower()})

    def _seg_label(self, state):
        return next((k for k, v in self.segments.items() if v == state), None)

    def _filter(self):
        q = self.search.get().strip().lower()
        for r in self.rows:
            r["row"].pack_forget()
        for r in self.rows:
            if q in r["text"]:
                r["row"].pack(fill="x", padx=6, pady=3)

    def _change(self, it, value):
        entry = next(r for r in self.rows if r["item"] is it)
        ctl = entry["ctl"]
        new = self.segments[value] if self.segments else value
        old = it["state"]
        ctl.configure(state="disabled")

        def done(res, err):
            if not self.winfo_exists():
                return
            ctl.configure(state="normal")
            if err:
                if self.segments:
                    ctl.set(self._seg_label(old))
                else:
                    ctl.select() if old else ctl.deselect()
                self.app.say(f"{it['title']}: {err}", "bad")
            else:
                it["state"] = new
                self.app.say(res, "ok")

        self.app.run_bg(lambda: self.setter(it["id"], new), done)

    def _reset(self, reset):
        def done(res, err):
            self.app.say(f"Restore: {err}" if err else res, "bad" if err else "ok")
            if not err and self.winfo_exists():
                self.message("Loading...")
                self.app.run_bg(self.loader, self._built)

        self.app.run_bg(reset, done)


class JunkDialog(BaseDialog):
    def __init__(self, app):
        super().__init__(app, "Deep clean", "Tick what to delete. Nothing is removed until you press Clean selected. "
                         "Files that are in use are skipped.", "600x620")
        self.checks = []
        self.total = ctk.CTkLabel(self.top, text="", font=app.f_bold, text_color=TEXT)
        self.total.pack(anchor="w")
        ctk.CTkButton(self.footer, text="Clean selected", width=140, fg_color=ACCENT, hover_color="#3d79e8",
                      command=self._clean).pack(side="right", padx=8)
        ctk.CTkButton(self.footer, text="Rescan", width=90, fg_color=ACCENT_SOFT, hover_color="#27365a",
                      command=self._scan).pack(side="left")
        self._scan()

    def _scan(self):
        self.message("Scanning...")
        self.total.configure(text="")
        self.app.run_bg(dt.scan_junk, self._built)

    def _built(self, items, err):
        if not self.winfo_exists():
            return
        if err:
            self.message(f"Scan failed: {err}")
            return
        self.clear()
        self.checks = []
        for it in items:
            cb = ctk.CTkCheckBox(self.box, text=f"{it['name']}  -  {dt.fmt_bytes(it['size'])}", checkbox_width=20,
                                 checkbox_height=20, fg_color=ACCENT, hover_color="#3d79e8", font=self.app.f_bold,
                                 command=self._update)
            cb.pack(anchor="w", padx=12, pady=(8, 0))
            note = it["desc"] + ("  (needs administrator)" if it["admin"] and not is_admin() else "")
            ctk.CTkLabel(self.box, text=note, font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED, wraplength=500,
                         justify="left").pack(anchor="w", padx=44)
            if it["default"] and it["size"]:
                cb.select()
            self.checks.append((it, cb))
        self._update()

    def _update(self):
        size = sum(it["size"] for it, cb in self.checks if cb.get())
        self.total.configure(text=f"Selected: {dt.fmt_bytes(size)}")

    def _clean(self):
        ids = [it["id"] for it, cb in self.checks if cb.get()]
        if not ids:
            return
        if not messagebox.askyesno(APP_NAME, "Delete the selected files? This can't be undone.", parent=self):
            return
        self.app.say("Cleaning...", "warn")

        def done(res, err):
            self.app.say(f"Deep clean: {err}" if err else res, "bad" if err else "ok")
            if self.winfo_exists():
                self._scan()

        self.app.run_bg(lambda: dt.clean_junk(ids), done)


class ProgramsDialog(BaseDialog):
    def __init__(self, app):
        super().__init__(app, "Installed programs", "Programs flagged as likely OEM / trial bloat are listed first. "
                         "Uninstall opens the program's own uninstaller.", "640x700")
        self.items = []
        self.search = ctk.CTkEntry(self.top, placeholder_text="Search programs...", height=30)
        self.search.pack(fill="x")
        self.search.bind("<KeyRelease>", lambda e: self._render())
        self.only = ctk.CTkSwitch(self.top, text="Only suspected bloat", font=app.f_small, text_color=MUTED,
                                  progress_color=ACCENT, command=self._render)
        self.only.pack(anchor="w", pady=6)
        self.message("Reading installed programs...")
        app.run_bg(dt.list_programs, self._built)

    def _built(self, items, err):
        if not self.winfo_exists():
            return
        if err:
            self.message(f"Could not read programs: {err}")
            return
        self.items = items
        if any(i["flag"] for i in items):
            self.only.select()
        self._render()

    def _render(self):
        q = self.search.get().strip().lower()
        only = bool(self.only.get())
        rows = [i for i in self.items if (not only or i["flag"]) and q in i["name"].lower()]
        self.clear()
        if not rows:
            self.message("No matching programs.")
            return
        for it in rows[:60]:
            row = ctk.CTkFrame(self.box, fg_color="transparent")
            row.pack(fill="x", padx=6, pady=3)
            text = ctk.CTkFrame(row, fg_color="transparent")
            text.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(text, text=it["name"], font=self.app.f_bold, text_color=TEXT, anchor="w").pack(anchor="w")
            bits = [b for b in (it["publisher"], dt.fmt_bytes(it["size"]) if it["size"] else "") if b]
            ctk.CTkLabel(text, text="  ·  ".join(bits), font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED,
                         anchor="w").pack(anchor="w")
            if it["flag"]:
                ctk.CTkLabel(text, text=f" {it['flag']} ", height=18, corner_radius=5, fg_color="#2b2417",
                             text_color=WARN, font=ctk.CTkFont("Segoe UI", 10, "bold")).pack(anchor="w", pady=2)
            ctk.CTkButton(row, text="Uninstall", width=84, height=28, fg_color="#c0392b", hover_color="#a93226",
                          command=lambda i=it: self._uninstall(i)).pack(side="right", padx=4)
        if len(rows) > 60:
            ctk.CTkLabel(self.box, text=f"Showing 60 of {len(rows)} - use the search box to narrow it down.",
                         font=self.app.f_small, text_color=MUTED).pack(anchor="w", padx=10, pady=8)

    def _uninstall(self, it):
        if not messagebox.askyesno(APP_NAME, f"Run the uninstaller for {it['name']}?", parent=self):
            return
        self.app.run_bg(lambda: dt.uninstall_program(it["id"]),
                        lambda r, e: self.app.say(f"{it['name']}: {e}" if e else r, "bad" if e else "ok"))


def open_dialog(app, kind):
    """Open one of the debloat dialogs by its action `ui` key."""
    if kind == "appx":
        AppxDialog(app)
    elif kind == "junk":
        JunkDialog(app)
    elif kind == "programs":
        ProgramsDialog(app)
    elif kind == "startup":
        ToggleListDialog(app, "Startup manager",
                         "Switch off what you don't need at startup. Entries are disabled, not deleted - switch "
                         "back on any time. 'All users' entries need administrator rights.",
                         dt.list_startup, dt.set_startup, filterable=True)
    elif kind == "tasks":
        ToggleListDialog(app, "Scheduled task cleaner",
                         "Telemetry and 'customer experience' tasks. Switch off to stop them; switch on to "
                         "restore. Needs administrator rights.", dt.list_tasks, dt.set_task)
    elif kind == "services":
        ToggleListDialog(app, "Services viewer",
                         "Optional services in plain English. Anything marked with a warning can break a feature "
                         "you use. 'Restore originals' undoes every change made here. Needs administrator rights.",
                         dt.list_services, dt.set_service,
                         segments={"Auto": "auto", "Manual": "manual", "Off": "off"}, reset=dt.reset_services,
                         filterable=True)
    elif kind == "context":
        ToggleListDialog(app, "Context-menu cleaner",
                         "Switch off entries you don't want in the right-click menu. Nothing is uninstalled. "
                         "Restart Explorer (Customise page) to apply. Needs administrator rights.",
                         dt.list_context, dt.set_context, filterable=True)


class QosDialog(ctk.CTkToplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title("Prioritise a game's traffic")
        self.geometry("520x560")
        self.configure(fg_color=BG)
        self.transient(app)
        self.after(200, self._modal)
        ctk.CTkLabel(self, text="Prioritise a game's traffic", font=app.f_title, text_color=TEXT
                     ).pack(anchor="w", padx=20, pady=(18, 0))
        ctk.CTkLabel(self, text="Tags the program's packets as high priority (DSCP 46). It only helps where your "
                     "router or Wi-Fi honours DSCP/WMM, and works best with 'Allow QoS priority tagging' switched on.",
                     font=app.f_small, text_color=MUTED, wraplength=470, justify="left"
                     ).pack(anchor="w", padx=20, pady=(2, 10))
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=20)
        self.entry = ctk.CTkEntry(row, placeholder_text="game.exe or full path", height=34)
        self.entry.pack(side="left", fill="x", expand=True)
        ctk.CTkButton(row, text="Browse", width=76, height=34, fg_color=ACCENT_SOFT, hover_color="#27365a",
                      command=self._browse).pack(side="left", padx=6)
        ctk.CTkButton(row, text="Add", width=64, height=34, fg_color=ACCENT, hover_color="#3d79e8",
                      command=self._add).pack(side="left")
        ctk.CTkLabel(self, text="ACTIVE POLICIES", font=ctk.CTkFont("Segoe UI", 11, "bold"), text_color=MUTED
                     ).pack(anchor="w", padx=20, pady=(16, 4))
        self.box = ctk.CTkScrollableFrame(self, fg_color=CARD)
        self.box.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        ctk.CTkButton(self, text="Close", width=90, fg_color="transparent", border_width=1, border_color=LINE,
                      command=self.destroy).pack(anchor="e", padx=20, pady=(0, 14))
        self._refresh()

    def _modal(self):
        try:
            self.grab_set()
            self.focus()
        except tk.TclError:
            pass

    def _browse(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[("Programs", "*.exe")])
        if path:
            self.entry.delete(0, "end")
            self.entry.insert(0, path)

    def _refresh(self):
        def done(res, err):
            if not self.winfo_exists():
                return
            for w in self.box.winfo_children():
                w.destroy()
            if err or not res:
                ctk.CTkLabel(self.box, text="No policies yet." if not err else str(err), text_color=MUTED,
                             font=self.app.f_small).pack(anchor="w", padx=8, pady=8)
                return
            for p in res:
                r = ctk.CTkFrame(self.box, fg_color="transparent")
                r.pack(fill="x", pady=3, padx=6)
                ctk.CTkLabel(r, text=p.get("app") or p["name"], text_color=TEXT, font=self.app.f_small).pack(side="left")
                ctk.CTkButton(r, text="Remove", width=72, height=26, fg_color="#c0392b", hover_color="#a93226",
                              command=lambda n=p["name"]: self._remove(n)).pack(side="right")

        self.app.run_bg(list_qos_policies, done)

    def _add(self):
        path = self.entry.get().strip()
        if not path:
            return

        def done(res, err):
            self.app.say(f"QoS policy: {err}" if err else res, "bad" if err else "ok")
            if not err and self.winfo_exists():
                self.entry.delete(0, "end")
                self._refresh()

        self.app.run_bg(lambda: add_qos_policy(path), done)

    def _remove(self, name):
        def done(res, err):
            self.app.say(f"QoS policy: {err}" if err else res, "bad" if err else "ok")
            if self.winfo_exists():
                self._refresh()

        self.app.run_bg(lambda: remove_qos_policy(name), done)


# ======================================================================= dashboard
class Dashboard(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app.content, fg_color="transparent")
        self.app = app
        ctk.CTkLabel(self, text="Dashboard", font=app.f_title, text_color=TEXT).pack(anchor="w")
        info = (f"{windows_name()}  ·  {psutil.cpu_count(logical=True)} threads  ·  "
                f"{psutil.virtual_memory().total / 2 ** 30:.0f} GB RAM")
        ctk.CTkLabel(self, text=info, font=app.f_small, text_color=MUTED).pack(anchor="w", pady=(2, 12))

        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="x")
        grid.grid_columnconfigure((0, 1), weight=1, uniform="c")
        self.cards = {}
        for i, (key, title) in enumerate([("cpu", "CPU"), ("gpu", "GPU"), ("ram", "Memory"), ("disp", "Display")]):
            card = ctk.CTkFrame(grid, fg_color=CARD, corner_radius=12)
            card.grid(row=i // 2, column=i % 2, sticky="nsew", padx=6, pady=6)
            ctk.CTkLabel(card, text=title.upper(), font=ctk.CTkFont("Segoe UI", 11, "bold"),
                         text_color=MUTED).pack(anchor="w", padx=18, pady=(14, 0))
            value = ctk.CTkLabel(card, text="--", font=ctk.CTkFont("Segoe UI", 30, "bold"), text_color=TEXT)
            value.pack(anchor="w", padx=18)
            bar = None
            if key != "disp":
                bar = ctk.CTkProgressBar(card, height=6, progress_color=ACCENT, fg_color=LINE)
                bar.set(0)
                bar.pack(fill="x", padx=18, pady=(2, 6))
            sub = ctk.CTkLabel(card, text="", font=app.f_small, text_color=MUTED)
            sub.pack(anchor="w", padx=18, pady=(0, 14))
            self.cards[key] = (value, sub, bar)

        quick = ctk.CTkFrame(self, fg_color=CARD, corner_radius=12)
        quick.pack(fill="x", padx=6, pady=(10, 0))
        left = ctk.CTkFrame(quick, fg_color="transparent")
        left.pack(side="left", padx=18, pady=14)
        ctk.CTkLabel(left, text="Performance overlay", font=app.f_bold, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(left, text="Floating FPS, temperatures, fan speeds and usage readout.",
                     font=app.f_small, text_color=MUTED).pack(anchor="w")
        sw = ctk.CTkSwitch(quick, text="", width=44, progress_color=ACCENT, fg_color="#2c3447")
        sw.configure(command=lambda: app.set_overlay(bool(sw.get())))
        sw.pack(side="right", padx=18)
        app.overlay_switches.append(sw)

        acts = ctk.CTkFrame(self, fg_color="transparent")
        acts.pack(fill="x", padx=6, pady=10)
        for action in [a for a in actions_for("admin") if a.id == "restore_point"] + \
                      [a for a in actions_for("boost") if a.id == "clean_temp"]:
            btn = ctk.CTkButton(acts, text=action.name, height=36, fg_color=ACCENT_SOFT,
                                hover_color="#27365a", text_color=TEXT)
            btn.configure(command=lambda a=action, b=btn: self._act(a, b))
            btn.pack(side="left", padx=(0, 8))

    def _act(self, action, btn):
        if action.admin and not is_admin():
            self.app.need_admin(action.name)
            return
        if action.confirm and not messagebox.askyesno(APP_NAME, action.confirm, parent=self.app):
            return
        btn.configure(state="disabled")

        def done(res, err):
            btn.configure(state="normal")
            self.app.say(f"{action.name}: {err}" if err else res, "bad" if err else "ok")

        self.app.run_bg(action.run, done)

    def update_stats(self, s):
        def pct(v):
            return "--" if v is None else f"{v:.0f}%"

        def deg(v):
            return None if v is None else f"{v:.0f} °C"

        v, sub, bar = self.cards["cpu"]
        v.configure(text=pct(s.get("cpu_usage")))
        bar.set((s.get("cpu_usage") or 0) / 100)
        sub.configure(text=deg(s.get("cpu_temp")) or "temperature: needs LibreHardwareMonitor")

        v, sub, bar = self.cards["gpu"]
        v.configure(text=pct(s.get("gpu_usage")))
        bar.set((s.get("gpu_usage") or 0) / 100)
        parts = [deg(s.get("gpu_temp"))]
        if s.get("vram_total"):
            parts.append(f"{s.get('vram_used', 0) / 1024:.1f}/{s['vram_total'] / 1024:.0f} GB VRAM")
        sub.configure(text="  ·  ".join(p for p in parts if p) or "no GPU sensor data")

        v, sub, bar = self.cards["ram"]
        v.configure(text=pct(s.get("ram_percent")))
        bar.set((s.get("ram_percent") or 0) / 100)
        sub.configure(text=f"{s.get('ram_used', 0):.1f} / {s.get('ram_total', 0):.1f} GB")

        v, sub, _ = self.cards["disp"]
        hz = s.get("refresh")
        v.configure(text="--" if not hz else f"{hz} Hz")
        fps = s.get("fps")
        sub.configure(text=(f"{fps:.0f} FPS  ·  {s.get('fps_app', '')}" if fps else "FPS: start the overlay to measure"))


# ======================================================================= admin tools page
class AdminPage(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app.content, fg_color="transparent")
        ctk.CTkLabel(self, text="Admin Tools", font=app.f_title, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(self, text="Launch Windows' own power tools on demand - each one opens elevated and "
                     "nothing runs until you click it.", font=app.f_small, text_color=MUTED
                     ).pack(anchor="w", pady=(2, 10))
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True)
        ctk.CTkLabel(scroll, text="LAUNCH", font=ctk.CTkFont("Segoe UI", 11, "bold"),
                     text_color=MUTED).pack(anchor="w", pady=(4, 6))
        grid = ctk.CTkFrame(scroll, fg_color="transparent")
        grid.pack(fill="x")
        grid.grid_columnconfigure((0, 1, 2), weight=1, uniform="t")
        for i, (label, desc, prog, args, elev) in enumerate(LAUNCHERS):
            b = ctk.CTkButton(grid, text=f"{label}\n{desc}", anchor="w", height=58, corner_radius=10,
                              fg_color=CARD, hover_color=CARD_HOVER, text_color=TEXT,
                              font=ctk.CTkFont("Segoe UI", 12))
            b.configure(command=lambda p=prog, a=args, e=elev, l=label: self._launch(app, l, p, a, e))
            b.grid(row=i // 3, column=i % 3, sticky="nsew", padx=4, pady=4)
        ctk.CTkLabel(scroll, text="MAINTENANCE", font=ctk.CTkFont("Segoe UI", 11, "bold"),
                     text_color=MUTED).pack(anchor="w", pady=(18, 4))
        for a in actions_for("admin"):
            ItemRow(scroll, app, a).pack(fill="x", pady=3)

    @staticmethod
    def _launch(app, label, prog, args, elev):
        try:
            launch(prog, args, elev)
            app.say(f"Opened {label}.", "ok")
        except Exception as e:
            app.say(f"{label}: {e}", "bad")


# ======================================================================= overlay page
class OverlayPage(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app.content, fg_color="transparent")
        self.app = app
        cfg = app.settings.overlay
        ctk.CTkLabel(self, text="Performance Overlay", font=app.f_title, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(self, text="A small always-on-top readout. Drag it anywhere; right-click it to close.",
                     font=app.f_small, text_color=MUTED).pack(anchor="w", pady=(2, 10))
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True)

        card = self._card(scroll)
        left = ctk.CTkFrame(card, fg_color="transparent")
        left.pack(side="left", padx=18, pady=14)
        ctk.CTkLabel(left, text="Show overlay", font=app.f_bold, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(left, text="Works over windowed and borderless games. Exclusive-fullscreen "
                     "games hide it - switch them to borderless.", font=app.f_small, text_color=MUTED,
                     wraplength=520, justify="left").pack(anchor="w")
        sw = ctk.CTkSwitch(card, text="", width=44, progress_color=ACCENT, fg_color="#2c3447")
        sw.configure(command=lambda: app.set_overlay(bool(sw.get())))
        sw.pack(side="right", padx=18)
        app.overlay_switches.append(sw)

        card = self._card(scroll, vertical=True)
        ctk.CTkLabel(card, text="Metrics", font=app.f_bold, text_color=TEXT).pack(anchor="w", padx=18, pady=(14, 6))
        grid = ctk.CTkFrame(card, fg_color="transparent")
        grid.pack(fill="x", padx=18, pady=(0, 14))
        grid.grid_columnconfigure((0, 1, 2), weight=1, uniform="m")
        for i, (key, label) in enumerate(METRIC_LABELS):
            cb = ctk.CTkCheckBox(grid, text=label, checkbox_width=20, checkbox_height=20,
                                 fg_color=ACCENT, hover_color="#3d79e8")
            cb.configure(command=lambda k=key, c=cb: app.set_metric(k, bool(c.get())))
            if cfg["metrics"].get(key):
                cb.select()
            cb.grid(row=i // 3, column=i % 3, sticky="w", pady=5)

        card = self._card(scroll, vertical=True)
        ctk.CTkLabel(card, text="Appearance", font=app.f_bold, text_color=TEXT).pack(anchor="w", padx=18, pady=(14, 6))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=4)
        ctk.CTkLabel(row, text="Opacity", width=120, anchor="w", text_color=MUTED, font=app.f_small).pack(side="left")
        slider = ctk.CTkSlider(row, from_=0.3, to=1.0, number_of_steps=14, width=220, progress_color=ACCENT,
                               button_color=ACCENT, button_hover_color="#3d79e8",
                               command=lambda v: app.set_overlay_value("opacity", round(float(v), 2)))
        slider.set(cfg["opacity"])
        slider.pack(side="left")
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=4)
        ctk.CTkLabel(row, text="Update rate", width=120, anchor="w", text_color=MUTED, font=app.f_small).pack(side="left")
        seg = ctk.CTkSegmentedButton(row, values=["0.5 s", "1 s", "2 s"], selected_color=ACCENT,
                                     command=lambda v: app.set_interval(float(v.split()[0])))
        seg.set(f"{cfg['interval']:g} s" if f"{cfg['interval']:g} s" in ("0.5 s", "1 s", "2 s") else "1 s")
        seg.pack(side="left")
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=18, pady=(4, 14))
        ctk.CTkLabel(row, text="Click-through", width=120, anchor="w", text_color=MUTED, font=app.f_small).pack(side="left")
        ct = ctk.CTkSwitch(row, text="mouse clicks pass through (can't drag while on)", width=44,
                           progress_color=ACCENT, fg_color="#2c3447", font=app.f_small, text_color=MUTED)
        ct.configure(command=lambda: app.set_overlay_value("click_through", bool(ct.get())))
        if cfg["click_through"]:
            ct.select()
        ct.pack(side="left")
        ctk.CTkButton(row, text="Reset position", width=120, height=28, fg_color=ACCENT_SOFT,
                      hover_color="#27365a", command=app.overlay.reset_position).pack(side="right")

        card = self._card(scroll, vertical=True)
        ctk.CTkLabel(card, text="Data sources", font=app.f_bold, text_color=TEXT).pack(anchor="w", padx=18, pady=(14, 6))
        self.status = {}
        for key, title in (("gpu", "GPU (NVIDIA / Windows counters)"),
                           ("lhm", "CPU temperature & fan speeds"),
                           ("fps", "FPS counter (PresentMon)")):
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=2)
            dot = ctk.CTkLabel(row, text="●", width=18, text_color=MUTED)
            dot.pack(side="left")
            ctk.CTkLabel(row, text=title, width=250, anchor="w", font=app.f_small, text_color=TEXT).pack(side="left")
            msg = ctk.CTkLabel(row, text="", anchor="w", font=app.f_small, text_color=MUTED, wraplength=360, justify="left")
            msg.pack(side="left", fill="x")
            self.status[key] = (dot, msg)
        btns = ctk.CTkFrame(card, fg_color="transparent")
        btns.pack(fill="x", padx=18, pady=(10, 14))
        self.dl_btn = ctk.CTkButton(btns, text="Download helper tools", height=32, fg_color=ACCENT,
                                    hover_color="#3d79e8", command=self._download)
        self.dl_btn.pack(side="left")
        ctk.CTkButton(btns, text="Start sensor service", height=32, fg_color=ACCENT_SOFT, hover_color="#27365a",
                      command=self._start_lhm).pack(side="left", padx=8)
        ctk.CTkButton(btns, text="Open tools folder", height=32, fg_color=ACCENT_SOFT, hover_color="#27365a",
                      command=self._open_tools).pack(side="left")
        ctk.CTkLabel(card, text="NVIDIA GPU data works out of the box. CPU temperature and fan RPM need "
                     "LibreHardwareMonitor running as administrator; the FPS counter needs PresentMon and "
                     "PC Tweaker running as administrator. Both helpers are free and downloaded from GitHub.",
                     font=app.f_small, text_color=MUTED, wraplength=640, justify="left"
                     ).pack(anchor="w", padx=18, pady=(0, 14))

    @staticmethod
    def _card(parent, vertical=False):
        c = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12)
        c.pack(fill="x", pady=5)
        return c

    def _download(self):
        self.dl_btn.configure(state="disabled", text="Downloading...")
        self.app.say("Downloading PresentMon and LibreHardwareMonitor from GitHub...", "warn")

        def done(res, err):
            self.dl_btn.configure(state="normal", text="Download helper tools")
            self.app.say(f"Download failed: {err}" if err else res, "bad" if err else "ok")
            self.app.ensure_fps()

        self.app.run_bg(helpers.download_all, done)

    def _start_lhm(self):
        exe = helpers.lhm_path()
        if not exe:
            self.app.say("LibreHardwareMonitor isn't downloaded yet - click 'Download helper tools'.", "warn")
            return
        ok = run_elevated(str(exe), "", 1)
        self.app.say("Started LibreHardwareMonitor. Keep it running (minimise it) for temperatures and fan "
                     "speeds." if ok else "Could not start it (UAC declined?).", "ok" if ok else "bad")

    def _open_tools(self):
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        os.startfile(str(TOOLS_DIR))

    def update_status(self, st, fps):
        def put(key, ok, text):
            dot, msg = self.status[key]
            dot.configure(text_color=OK if ok else WARN)
            msg.configure(text=text)

        put("gpu", st.get("nvml") or st.get("gpu_counters") or st.get("lhm"),
            "NVIDIA sensors active" if st.get("nvml") else
            "Using Windows GPU counters" if st.get("gpu_counters") else
            "Active via LibreHardwareMonitor" if st.get("lhm") else "No GPU data yet")
        put("lhm", st.get("lhm") or st.get("lib"),
            "Active" if st.get("lhm") or st.get("lib") else "Not running - start LibreHardwareMonitor or enable Fan Control")
        if fps.running:
            put("fps", True, "Active" + (f" - {fps.current_app}" if fps.current_app else " - waiting for a game"))
        elif not fps.available:
            put("fps", False, "PresentMon not downloaded")
        elif not is_admin():
            put("fps", False, "Restart PC Tweaker as administrator")
        else:
            put("fps", False, fps.last_error or "Stopped (turns on with the overlay)")



# ======================================================================= fan control page
class FanCard(ctk.CTkFrame):
    def __init__(self, master, app, ch):
        super().__init__(master, fg_color=CARD, corner_radius=12)
        self.app, self.ch = app, ch
        head = ctk.CTkFrame(self, fg_color="transparent")
        head.pack(fill="x", padx=18, pady=(14, 0))
        title = ctk.CTkFrame(head, fg_color="transparent")
        title.pack(side="left")
        ctk.CTkLabel(title, text=ch.name, font=app.f_bold, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(title, text=ch.hardware, font=ctk.CTkFont("Segoe UI", 11), text_color=MUTED).pack(anchor="w")
        self.live = ctk.CTkLabel(head, text="--", font=ctk.CTkFont("Segoe UI", 15, "bold"), text_color=TEXT)
        self.live.pack(side="right")

        self.seg = ctk.CTkSegmentedButton(self, values=["Auto", "Manual", "Curve"], selected_color=ACCENT,
                                          command=self._mode)
        self.seg.pack(anchor="w", padx=18, pady=(10, 6))

        self.manual_box = ctk.CTkFrame(self, fg_color="transparent")
        self.manual_val = ctk.CTkLabel(self.manual_box, text="", width=52, text_color=TEXT, font=app.f_bold)
        self.manual_val.pack(side="right")
        self.manual_slider = ctk.CTkSlider(self.manual_box, from_=ch.floor, to=100, number_of_steps=100 - ch.floor,
                                           progress_color=ACCENT, button_color=ACCENT, button_hover_color="#3d79e8",
                                           command=self._manual)
        self.manual_slider.pack(side="left", fill="x", expand=True)

        self.curve_box = ctk.CTkFrame(self, fg_color="transparent")
        top = ctk.CTkFrame(self.curve_box, fg_color="transparent")
        top.pack(fill="x", pady=(0, 4))
        ctk.CTkLabel(top, text="Follow temperature of", font=app.f_small, text_color=MUTED).pack(side="left")
        self.src = ctk.CTkSegmentedButton(top, values=["CPU", "GPU", "Hottest"], selected_color=ACCENT,
                                          command=self._source)
        self.src.pack(side="left", padx=10)
        self.curve_sliders, self.curve_labels = [], []
        for i, t in enumerate(CURVE_TEMPS):
            row = ctk.CTkFrame(self.curve_box, fg_color="transparent")
            row.pack(fill="x", pady=1)
            ctk.CTkLabel(row, text=f"{t} °C", width=52, anchor="w", font=app.f_small, text_color=MUTED).pack(side="left")
            val = ctk.CTkLabel(row, text="", width=48, text_color=TEXT, font=app.f_small)
            val.pack(side="right")
            sl = ctk.CTkSlider(row, from_=ch.floor, to=100, number_of_steps=100 - ch.floor, progress_color=ACCENT,
                               button_color=ACCENT, button_hover_color="#3d79e8",
                               command=lambda v, i=i: self._curve(i, v))
            sl.pack(side="left", fill="x", expand=True)
            self.curve_sliders.append(sl)
            self.curve_labels.append(val)

        self.note = ctk.CTkLabel(self, text="", font=app.f_small, text_color=WARN, wraplength=620, justify="left")
        self.note.pack(anchor="w", padx=18, pady=(6, 12))
        self.sync()

    # ---- state <-> widgets
    def sync(self):
        ch = self.ch
        self.seg.set(ch.mode.capitalize())
        self.src.set({"cpu": "CPU", "gpu": "GPU", "hottest": "Hottest"}[ch.source])
        self.manual_slider.set(max(ch.manual, ch.floor))
        self.manual_val.configure(text=f"{ch.manual}%")
        for i, sl in enumerate(self.curve_sliders):
            sl.set(max(ch.curve[i], ch.floor))
            self.curve_labels[i].configure(text=f"{ch.curve[i]}%")
        self._layout()

    def _layout(self):
        self.manual_box.pack_forget()
        self.curve_box.pack_forget()
        if self.ch.mode == "manual":
            self.manual_box.pack(fill="x", padx=18, pady=(2, 0), before=self.note)
        elif self.ch.mode == "curve":
            self.curve_box.pack(fill="x", padx=18, pady=(2, 0), before=self.note)

    def _mode(self, value):
        self.ch.mode = value.lower()
        self._layout()
        self.app.schedule_fan_save()

    def _source(self, value):
        self.ch.source = value.lower()
        self.app.schedule_fan_save()

    def _manual(self, v):
        self.ch.manual = int(round(v))
        self.manual_val.configure(text=f"{self.ch.manual}%")
        self.app.schedule_fan_save()

    def _curve(self, i, v):
        self.ch.curve[i] = int(round(v))
        self.curve_labels[i].configure(text=f"{self.ch.curve[i]}%")
        self.app.schedule_fan_save()

    def update_live(self):
        ch = self.ch
        parts = []
        if ch.rpm is not None:
            parts.append(f"{ch.rpm:.0f} RPM")
        if ch.percent is not None:
            parts.append(f"{ch.percent:.0f}%")
        self.live.configure(text="  ·  ".join(parts) or "--")
        self.note.configure(text=ch.note)


class FanPage(ctk.CTkFrame):
    def __init__(self, app):
        super().__init__(app.content, fg_color="transparent")
        self.app = app
        self.version = -1
        self.cards = {}
        ctk.CTkLabel(self, text="Fan Control", font=app.f_title, text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(self, text="Set custom fan speeds: fixed, or following a temperature curve.",
                     font=app.f_small, text_color=MUTED).pack(anchor="w", pady=(2, 10))

        warn = ctk.CTkFrame(self, fg_color="#2b2417", corner_radius=10)
        warn.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(warn, text=(f"This writes directly to your hardware. Speeds below {MIN_PCT}% are blocked, fans jump to "
                                 f"100% if the CPU reaches {CPU_LIMIT:.0f} °C or the GPU {GPU_LIMIT:.0f} °C, and every fan "
                                 "returns to automatic when you switch this off or close the app."),
                     font=app.f_small, text_color=WARN, wraplength=700, justify="left").pack(padx=16, pady=10, anchor="w")

        master = ctk.CTkFrame(self, fg_color=CARD, corner_radius=12)
        master.pack(fill="x", pady=4)
        left = ctk.CTkFrame(master, fg_color="transparent")
        left.pack(side="left", padx=18, pady=14, fill="x", expand=True)
        ctk.CTkLabel(left, text="Enable fan control", font=app.f_bold, text_color=TEXT).pack(anchor="w")
        self.status = ctk.CTkLabel(left, text="", font=app.f_small, text_color=MUTED, wraplength=520, justify="left")
        self.status.pack(anchor="w")
        self.switch = ctk.CTkSwitch(master, text="", width=44, progress_color=ACCENT, fg_color="#2c3447",
                                    command=self._toggle)
        self.switch.pack(side="right", padx=18)
        ctk.CTkButton(master, text="All to automatic", width=130, height=30, fg_color=ACCENT_SOFT,
                      hover_color="#27365a", command=self._all_auto).pack(side="right", padx=4)

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True)

    def _toggle(self):
        app, f = self.app, self.app.fans
        if not self.switch.get():
            f.stop()
            return
        if not is_admin():
            self.switch.deselect()
            app.need_admin("Fan control")
            return
        if not messagebox.askyesno(
                APP_NAME,
                "Fan control changes how your cooling behaves. Wrong settings can make hardware run hot.\n\n"
                "Safety limits are enforced and all fans return to automatic when you switch this off or exit, "
                "but you are responsible for monitoring your temperatures.\n\n"
                "Any speeds you saved earlier will be applied now. Continue?", parent=app):
            self.switch.deselect()
            return
        f.start(saved=app.settings.data.get("fans", {}))

    def _all_auto(self):
        self.app.fans.restore_all_auto()
        for c in self.cards.values():
            c.sync()
        self.app.schedule_fan_save()
        self.app.say("All fans set to automatic.", "ok")

    def update(self):
        f = self.app.fans
        text = f.message
        self.status.configure(text=text, text_color=BAD if f.state == "error" else MUTED)
        if f.active and not self.switch.get():
            self.switch.select()
        elif not f.active and self.switch.get():
            self.switch.deselect()
        if f.version != self.version:
            self.version = f.version
            for c in self.cards.values():
                c.destroy()
            self.cards = {}
            for ch in f.channels:
                card = FanCard(self.scroll, self.app, ch)
                card.pack(fill="x", pady=5)
                self.cards[ch.id] = card
        for c in self.cards.values():
            c.update_live()

# ======================================================================= main window
class App(ctk.CTk):
    def __init__(self):
        ctk.set_appearance_mode("dark")
        super().__init__()
        self.title(f"{APP_NAME} {__version__}")
        self.geometry("1080x720")
        self.minsize(960, 620)
        self.configure(fg_color=BG)
        self.after(250, self._set_icon)

        self.f_title = ctk.CTkFont("Segoe UI", 24, "bold")
        self.f_bold = ctk.CTkFont("Segoe UI", 14, "bold")
        self.f_small = ctk.CTkFont("Segoe UI", 12)

        self.settings = Settings()
        self.fps = PresentMonReader()
        self.sensors = Sensors(self.fps)
        self.sensors.interval = float(self.settings.overlay["interval"])
        self.fans = FanController()
        self.sensors.extra = self.fans.snapshot_readings
        self._fan_save_job = None
        self.overlay = Overlay(self, self.sensors, self.settings)
        self.overlay.on_hidden = self._overlay_hidden
        self.overlay_switches = []
        self.uiq = queue.Queue()

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()
        main = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(0, weight=1)
        self.content = ctk.CTkFrame(main, fg_color="transparent")
        self.content.grid(row=0, column=0, sticky="nsew", padx=26, pady=(22, 0))
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(0, weight=1)
        bar = ctk.CTkFrame(main, fg_color=SIDEBAR, corner_radius=0, height=34)
        bar.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        self.status_label = ctk.CTkLabel(bar, text="Ready.", font=self.f_small, text_color=MUTED, anchor="w")
        self.status_label.pack(side="left", padx=18, pady=6)

        self.dashboard = Dashboard(self)
        self.overlay_page = OverlayPage(self)
        self.pages = {
            "Dashboard": self.dashboard,
            "FPS & Boost": ListPage(self, "FPS & Boost", "Performance tweaks. Every switch can be turned back off "
                                    "to restore your previous setting.",
                                    [("Tweaks", by_category("boost")), ("Quick actions", actions_for("boost"))]),
            "Network": ListPage(self, "Network", "Lower latency and improve responsiveness. Gains depend on your "
                                "connection - measure with 'Test latency' before and after.",
                                [("Latency tweaks", by_category("network")), ("Tools", actions_for("network"))],
                                banner=("Tip: run a latency test first so you can see what each tweak actually changes.",
                                        "Test latency", self._latency_test)),
            "Debloat": ListPage(self, "Debloat & Privacy", "Cut background noise, telemetry and preinstalled clutter.",
                                [("Privacy & services", by_category("debloat")),
                                 ("Apps & programs", actions_for("debloat_apps")),
                                 ("Startup & background", actions_for("debloat_startup")),
                                 ("Cleanup", actions_for("debloat_clean"))],
                                banner=("Tip: create a restore point before making system-wide changes.",
                                        "Create restore point", self._restore_point)),
            "Fan Control": FanPage(self),
            "Customise": ListPage(self, "Customise", "Make Windows look and behave the way you like.",
                                  [("Look & feel", by_category("customise")), ("Apply", actions_for("customise"))]),
            "Admin Tools": AdminPage(self),
            "Overlay": self.overlay_page,
        }
        self.show("Dashboard")
        self.after(80, self._drain)
        self.after(500, self._tick_ui)
        self.sensors.start()
        self.refresh_states()
        if self.settings.overlay["enabled"]:
            self.after(700, lambda: self.set_overlay(True))
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------------------------------------------------------- layout
    def _set_icon(self):
        try:
            self.iconbitmap(str(resource_path("assets/icon.ico")))
        except Exception:
            pass

    def _build_sidebar(self):
        side = ctk.CTkFrame(self, width=210, corner_radius=0, fg_color=SIDEBAR)
        side.grid(row=0, column=0, sticky="nsw")
        side.grid_propagate(False)
        side.grid_rowconfigure(10, weight=1)
        ctk.CTkLabel(side, text="PC Tweaker", font=ctk.CTkFont("Segoe UI", 21, "bold"), text_color=TEXT
                     ).grid(row=0, column=0, sticky="w", padx=22, pady=(24, 0))
        ctk.CTkLabel(side, text=f"v{__version__}  ·  Windows", font=self.f_small, text_color=MUTED
                     ).grid(row=1, column=0, sticky="w", padx=22, pady=(0, 18))
        self.nav = {}
        for i, name in enumerate(["Dashboard", "FPS & Boost", "Network", "Debloat", "Customise", "Fan Control", "Admin Tools", "Overlay"]):
            b = ctk.CTkButton(side, text=name, anchor="w", height=40, corner_radius=8, width=176,
                              font=ctk.CTkFont("Segoe UI", 13, "bold"), fg_color="transparent",
                              hover_color="#1b2130", text_color=MUTED, command=lambda n=name: self.show(n))
            b.grid(row=2 + i, column=0, padx=17, pady=2)
            self.nav[name] = b
        box = ctk.CTkFrame(side, fg_color=CARD, corner_radius=10)
        box.grid(row=11, column=0, padx=14, pady=16, sticky="ew")
        admin = is_admin()
        ctk.CTkLabel(box, text="● Administrator" if admin else "● Standard user", font=self.f_small,
                     text_color=OK if admin else WARN).pack(anchor="w", padx=14, pady=(10, 2))
        if not admin:
            ctk.CTkLabel(box, text="Some tweaks need admin rights.", font=ctk.CTkFont("Segoe UI", 11),
                         text_color=MUTED, wraplength=150, justify="left").pack(anchor="w", padx=14)
            ctk.CTkButton(box, text="Restart as admin", height=30, fg_color=ACCENT, hover_color="#3d79e8",
                          command=lambda: self.need_admin("PC Tweaker", ask=False)).pack(padx=12, pady=10, fill="x")
        else:
            ctk.CTkLabel(box, text="All tools unlocked.", font=ctk.CTkFont("Segoe UI", 11),
                         text_color=MUTED).pack(anchor="w", padx=14, pady=(0, 10))

    def show(self, name):
        for n, page in self.pages.items():
            if n == name:
                page.grid(row=0, column=0, sticky="nsew")
            else:
                page.grid_remove()
        for n, b in self.nav.items():
            b.configure(fg_color=ACCENT_SOFT if n == name else "transparent",
                        text_color=TEXT if n == name else MUTED)

    # ---------------------------------------------------------------- helpers
    def say(self, text, kind="info"):
        color = {"ok": OK, "bad": BAD, "warn": WARN}.get(kind, MUTED)
        self.status_label.configure(text=" ".join(str(text).split())[:220], text_color=color)

    def run_bg(self, fn, done=None):
        def work():
            try:
                res, err = fn(), None
            except Exception as e:  # shown to the user in the status bar
                res, err = None, e
            if done:
                self.uiq.put(lambda: done(res, err))
        threading.Thread(target=work, daemon=True).start()

    def _drain(self):
        try:
            while True:
                self.uiq.get_nowait()()
        except queue.Empty:
            pass
        self.after(80, self._drain)

    def need_admin(self, what, ask=True):
        if ask and not messagebox.askyesno(
                "Administrator needed",
                f"'{what}' changes system-wide settings and needs administrator rights.\n\n"
                "Restart PC Tweaker as administrator now?", parent=self):
            return
        if relaunch_as_admin():
            self.on_close()
        else:
            self.say("Elevation was cancelled.", "warn")

    def _latency_test(self):
        action = next(a for a in actions_for("network") if a.id == "latency_test")
        self.say("Testing latency (about 5 seconds)...", "warn")
        self.run_bg(action.run, lambda r, e: self.say(f"Latency test: {e}" if e else r, "bad" if e else "ok"))

    def _restore_point(self):
        action = next(a for a in actions_for("admin") if a.id == "restore_point")
        if not is_admin():
            self.need_admin(action.name)
            return
        self.say("Creating restore point...", "warn")
        self.run_bg(action.run, lambda r, e: self.say(f"{action.name}: {e}" if e else r, "bad" if e else "ok"))

    def refresh_states(self):
        rows = [r for p in self.pages.values() if isinstance(p, ListPage) for r in p.rows]

        def work():
            out = []
            for r in rows:
                try:
                    out.append((r, r.item.is_applied()))
                except Exception:
                    out.append((r, False))
            return out

        def done(res, err):
            for r, ok in res or []:
                r.set_state(ok)

        self.run_bg(work, done)

    # ---------------------------------------------------------------- overlay control
    def set_overlay(self, on: bool):
        if on and not self.overlay.visible:
            self.overlay.show()
            self.ensure_fps()
        elif not on and self.overlay.visible:
            self.overlay.hide()
        self._sync_switches()

    def _overlay_hidden(self):
        self.fps.stop()
        self._sync_switches()

    def _sync_switches(self):
        for sw in self.overlay_switches:
            sw.select() if self.overlay.visible else sw.deselect()

    def set_metric(self, key, on):
        self.settings.overlay["metrics"][key] = on
        self.settings.save()
        self.overlay.refresh()
        if key == "fps":
            self.ensure_fps() if on else self.fps.stop()

    def set_overlay_value(self, key, value):
        self.settings.overlay[key] = value
        self.settings.save()
        self.overlay.apply_settings()

    def set_interval(self, seconds):
        self.settings.overlay["interval"] = seconds
        self.sensors.interval = seconds
        self.settings.save()

    def ensure_fps(self):
        """Start PresentMon when the overlay wants FPS and everything needed is present."""
        if not (self.overlay.visible and self.settings.overlay["metrics"].get("fps")):
            return
        if self.fps.running or not self.fps.available:
            return
        if not is_admin():
            self.say("FPS counter needs PC Tweaker running as administrator (sidebar > Restart as admin).", "warn")
            return
        self.run_bg(self.fps.start, lambda r, e: self.say(
            r[1] if r and r[0] else f"FPS counter: {(r[1] if r else e)}", "ok" if r and r[0] else "warn"))

    # ---------------------------------------------------------------- fan settings persistence
    def schedule_fan_save(self):
        if self._fan_save_job:
            self.after_cancel(self._fan_save_job)
        self._fan_save_job = self.after(600, self._save_fans)

    def _save_fans(self):
        self._fan_save_job = None
        fans = self.settings.data.setdefault("fans", {})
        for ch in self.fans.channels:
            fans[ch.id] = ch.to_cfg()
        self.settings.save()

    # ---------------------------------------------------------------- periodic UI refresh
    def _tick_ui(self):
        try:
            self.dashboard.update_stats(self.sensors.snapshot())
            self.overlay_page.update_status(self.sensors.status, self.fps)
            self.pages["Fan Control"].update()
        except Exception:
            pass
        self.after(1000, self._tick_ui)

    def on_close(self):
        try:
            if self.overlay.visible:
                keep = self.settings.overlay["enabled"]
                self.overlay.hide()
                self.settings.overlay["enabled"] = keep
            self.settings.save()
            self.fps.stop()
            self.sensors.stop()
            self.fans.stop(wait=True)
        finally:
            self.destroy()
