"""Custom fan speeds.

Backends
  * LibreHardwareMonitor library (via pythonnet): motherboard fan headers + GPU fans
  * NVIDIA NVML: GPU fans, used only when the library found no GPU fan control

Safety rules (enforced here, not just in the UI)
  * speeds below MIN_PCT are never written
  * any fan in Manual/Curve mode jumps to 100 % if the CPU reaches CPU_LIMIT or the GPU GPU_LIMIT
  * if a fan write fails or temperatures are unavailable, that fan is handed back to automatic
  * every fan is returned to automatic when fan control is switched off or the app exits
"""
import atexit
import sys
import threading
import time

from . import helpers
from .registry import key_exists
from .sensors import parse_lhm

CURVE_TEMPS = (30, 45, 60, 75, 90)
DEFAULT_CURVE = (30, 40, 55, 80, 100)
MIN_PCT = 20
CPU_LIMIT, GPU_LIMIT, HYSTERESIS = 90.0, 88.0, 5.0
KEEPALIVE = 10.0   # seconds; firmware/drivers may reclaim a fan, so re-assert the speed


# ----------------------------------------------------------------------- pure logic
def clamp_pct(p, floor=MIN_PCT):
    return int(max(floor, min(100, round(p))))


def interp_curve(curve, temp):
    pts = list(zip(CURVE_TEMPS, curve))
    if temp <= pts[0][0]:
        return float(pts[0][1])
    if temp >= pts[-1][0]:
        return float(pts[-1][1])
    for (t0, p0), (t1, p1) in zip(pts, pts[1:]):
        if t0 <= temp <= t1:
            return p0 + (p1 - p0) * (temp - t0) / (t1 - t0)
    return float(pts[-1][1])


def pick_temp(source, temps):
    cpu, gpu = temps.get("cpu"), temps.get("gpu")
    if source == "cpu":
        return cpu
    if source == "gpu":
        return gpu
    vals = [t for t in (cpu, gpu) if t is not None]
    return max(vals) if vals else None


def compute_target(mode, manual, curve, source, temps, override, floor=MIN_PCT):
    """-> (percent, or None meaning 'leave on automatic', note)"""
    if mode == "auto":
        return None, ""
    if override:
        return 100, "Safety limit: temperature too high - running at 100%"
    if temps.get("cpu") is None and temps.get("gpu") is None:
        return None, "No temperature readings - left on automatic for safety"
    if mode == "manual":
        return clamp_pct(manual, floor), ""
    t = pick_temp(source, temps)
    if t is None:
        return None, "No reading for the chosen temperature source - left on automatic"
    return clamp_pct(interp_curve(curve, t), floor), ""


def pawnio_installed() -> bool:
    return key_exists("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PawnIO")


# ----------------------------------------------------------------------- channel
class Channel:
    def __init__(self, cid, name, hardware, backend, ctrl, is_gpu, fan_id=None, floor=MIN_PCT):
        self.id, self.name, self.hardware = cid, name, hardware
        self.backend, self.ctrl, self.is_gpu, self.fan_id = backend, ctrl, is_gpu, fan_id
        self.floor = max(MIN_PCT, int(floor or 0))
        self.mode = "auto"
        self.manual = 50
        self.curve = list(DEFAULT_CURVE)
        self.source = "gpu" if is_gpu else "cpu"
        self.percent = None
        self.rpm = None
        self.note = ""
        self.error = ""          # sticky message after a failed write
        self.applied = None
        self.last_apply = 0.0

    def to_cfg(self):
        return {"mode": self.mode, "manual": self.manual, "curve": list(self.curve), "source": self.source}

    def load_cfg(self, cfg):
        if not isinstance(cfg, dict):
            return
        if cfg.get("mode") in ("auto", "manual", "curve"):
            self.mode = cfg["mode"]
        if isinstance(cfg.get("manual"), (int, float)):
            self.manual = clamp_pct(cfg["manual"])
        c = cfg.get("curve")
        if isinstance(c, list) and len(c) == len(CURVE_TEMPS) and all(isinstance(x, (int, float)) for x in c):
            self.curve = [clamp_pct(x) for x in c]
        if cfg.get("source") in ("cpu", "gpu", "hottest"):
            self.source = cfg["source"]


# ----------------------------------------------------------------------- backends
def _load_lhm_library():
    dll = helpers.lhm_lib_path()
    if not dll:
        raise RuntimeError("LibreHardwareMonitor isn't downloaded yet (Overlay page > Download helper tools).")
    try:
        import pythonnet
    except ImportError:
        raise RuntimeError("The 'pythonnet' package is missing (pip install pythonnet).")
    try:
        pythonnet.load("netfx")
    except Exception:
        pass  # already loaded
    import clr
    folder = dll.parent
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))
    from System.Reflection import Assembly
    for f in sorted(folder.glob("*.dll")):       # make sure dependencies resolve from this folder
        try:
            Assembly.LoadFrom(str(f))
        except Exception:
            pass
    try:
        clr.AddReference("LibreHardwareMonitorLib")
    except Exception:
        clr.AddReference(str(dll))


class LhmBackend:
    name = "lhm"

    def __init__(self):
        self.computer = None

    def open(self):
        _load_lhm_library()
        from LibreHardwareMonitor.Hardware import Computer
        c = Computer()
        c.IsCpuEnabled = True
        c.IsGpuEnabled = True
        c.IsMotherboardEnabled = True
        c.IsControllerEnabled = True
        c.Open()
        self.computer = c
        channels = []
        for hw, s in self._walk():
            if str(s.SensorType) != "Control" or s.Control is None:
                continue
            ident = str(s.Identifier)
            ctrl = s.Control
            floor = 0
            try:
                floor = float(ctrl.MinSoftwareValue)
            except Exception:
                pass
            name = " ".join(str(s.Name).replace("Control", "").split()) or str(s.Name)
            channels.append(Channel(ident, name, str(hw.Name), "lhm", ctrl, "/gpu" in ident.lower(),
                                    fan_id=ident.replace("/control/", "/fan/"), floor=floor))
        return channels

    def _walk(self):
        queue = list(self.computer.Hardware)
        while queue:
            hw = queue.pop(0)
            hw.Update()
            for s in hw.Sensors:
                yield hw, s
            queue.extend(hw.SubHardware)

    def poll(self):
        rows, vals = [], {}
        for _, s in self._walk():
            v = s.Value
            ident = str(s.Identifier)
            v = None if v is None else float(v)
            rows.append((str(s.Name), str(s.SensorType), v, ident))
            if v is not None:
                vals[ident] = v
        return rows, vals

    def set(self, ch, pct):
        ch.ctrl.SetSoftware(float(pct))

    def default(self, ch):
        ch.ctrl.SetDefault()

    def close(self):
        if self.computer is not None:
            try:
                self.computer.Close()
            except Exception:
                pass
            self.computer = None


class NvmlBackend:
    name = "nvml"

    def __init__(self):
        self.nv = None
        self.h = None
        self.channels = []

    def open(self):
        import pynvml as nv
        nv.nvmlInit()
        self.nv, self.h = nv, nv.nvmlDeviceGetHandleByIndex(0)
        gpu = nv.nvmlDeviceGetName(self.h)
        gpu = gpu.decode() if isinstance(gpu, bytes) else str(gpu)
        for i in range(nv.nvmlDeviceGetNumFans(self.h)):
            nv.nvmlDeviceGetFanControlPolicy_v2(self.h, i)   # raises if fan control is unsupported
            self.channels.append(Channel(f"nvml:{i}", f"GPU fan {i + 1}", gpu, "nvml", (self.h, i), True))
        return list(self.channels)

    def poll(self):
        nv, vals, rows = self.nv, {}, []
        try:
            rows.append(("GPU Core", "Temperature", float(nv.nvmlDeviceGetTemperature(self.h, nv.NVML_TEMPERATURE_GPU)),
                         "/gpu-nvidia/0/temperature/0"))
        except Exception:
            pass
        for ch in self.channels:
            try:
                vals[ch.id] = float(nv.nvmlDeviceGetFanSpeed_v2(self.h, ch.ctrl[1]))
            except Exception:
                pass
        return rows, vals

    def set(self, ch, pct):
        h, i = ch.ctrl
        self.nv.nvmlDeviceSetFanControlPolicy(h, i, self.nv.NVML_FAN_POLICY_MANUAL)
        self.nv.nvmlDeviceSetFanSpeed_v2(h, i, int(pct))

    def default(self, ch):
        h, i = ch.ctrl
        self.nv.nvmlDeviceSetDefaultFanSpeed_v2(h, i)

    def close(self):
        pass


def default_backends():
    return [LhmBackend(), NvmlBackend()]


# ----------------------------------------------------------------------- controller
class FanController:
    def __init__(self, backend_factory=default_backends):
        self.backend_factory = backend_factory
        self.state = "off"            # off | starting | running | error
        self.message = "Off - fans are under normal automatic control."
        self.channels = []
        self.version = 0              # bumps whenever the channel list changes (UI rebuild)
        self.override = False
        self.temps = {}
        self.readings = {}
        self._backends = []
        self._stop = threading.Event()
        self._thread = None
        self._lock = threading.Lock()
        atexit.register(self.stop, True)

    # ---- public API (UI thread)
    @property
    def active(self) -> bool:
        return self._thread is not None and self._thread.is_alive() and self.state in ("starting", "running")

    def snapshot_readings(self) -> dict:
        with self._lock:
            return dict(self.readings)

    def start(self, saved=None):
        if self.active:
            return
        self._stop.clear()
        self.state, self.message = "starting", "Starting fan control..."
        self._thread = threading.Thread(target=self._run, args=(saved or {},), daemon=True)
        self._thread.start()

    def stop(self, wait=False):
        self._stop.set()
        t = self._thread
        if wait and t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=6)

    def restore_all_auto(self):
        for ch in self.channels:
            ch.mode = "auto"

    # ---- worker
    def _run(self, saved):
        try:
            self._open(saved)
        except Exception as e:
            self.state, self.message = "error", f"Fan control failed to start: {e}"
        if self.state == "starting":
            self.state = "running"
        try:
            while not self._stop.is_set() and self.state == "running":
                t0 = time.time()
                try:
                    self._poll()
                    self._apply(t0)
                except Exception as e:
                    self.message = f"Fan control error: {e}"
                    self.restore_all_auto()
                self._stop.wait(max(0.1, 1.0 - (time.time() - t0)))
        finally:
            self._release()
            self.state = "off" if self.state != "error" else "error"
            if self.state == "off":
                self.message = "Off - fans are under normal automatic control."

    def _open(self, saved):
        problems, channels = [], []
        self._backends = []
        for b in self.backend_factory():
            try:
                chans = b.open()
            except Exception as e:
                problems.append(f"{b.name}: {e}")
                try:
                    b.close()
                except Exception:
                    pass
                continue
            if b.name == "nvml" and any(c.is_gpu for c in channels):
                b.close()           # the library already controls the GPU fan
                continue
            self._backends.append(b)
            channels.extend(chans)
        for ch in channels:
            ch.load_cfg(saved.get(ch.id))
        self.channels = channels
        self.version += 1
        if channels:
            self.message = f"{len(channels)} controllable fan(s) found."
        else:
            hint = ("No controllable fans found. Laptops and many prebuilt PCs lock fan control in firmware. "
                    "On a desktop, run PC Tweaker as administrator and make sure the PawnIO driver is "
                    "installed (pawnio.eu).")
            if not pawnio_installed():
                hint += " PawnIO was not detected on this PC."
            if problems:
                hint += " (" + "; ".join(problems) + ")"
            self.message = hint

    def _poll(self):
        rows, vals = [], {}
        for b in self._backends:
            r, v = b.poll()
            rows.extend(r)
            vals.update(v)
        reads = parse_lhm(rows)
        with self._lock:
            self.readings = reads
        self.temps = {"cpu": reads.get("cpu_temp"), "gpu": reads.get("gpu_temp")}
        cpu, gpu = self.temps["cpu"], self.temps["gpu"]
        hot = (cpu is not None and cpu >= CPU_LIMIT) or (gpu is not None and gpu >= GPU_LIMIT)
        cool = (cpu is None or cpu < CPU_LIMIT - HYSTERESIS) and (gpu is None or gpu < GPU_LIMIT - HYSTERESIS)
        if hot:
            self.override = True
        elif cool:
            self.override = False
        for ch in self.channels:
            ch.percent = vals.get(ch.id)
            ch.rpm = vals.get(ch.fan_id) if ch.fan_id else None

    def _backend(self, name):
        return next(b for b in self._backends if b.name == name)

    def _apply(self, now):
        for ch in self.channels:
            target, note = compute_target(ch.mode, ch.manual, ch.curve, ch.source,
                                          self.temps, self.override, ch.floor)
            ch.note = note or ch.error
            b = self._backend(ch.backend)
            try:
                if target is None:
                    if ch.applied is not None:
                        b.default(ch)
                        ch.applied = None
                elif ch.applied != target or now - ch.last_apply >= KEEPALIVE:
                    b.set(ch, target)
                    ch.applied, ch.last_apply = target, now
                    ch.error = ""
            except Exception as e:
                ch.mode, ch.applied = "auto", None
                ch.error = f"Could not control this fan ({e}) - returned to automatic"
                ch.note = ch.error
                try:
                    b.default(ch)
                except Exception:
                    pass

    def _release(self):
        for ch in self.channels:
            if ch.applied is not None:
                try:
                    self._backend(ch.backend).default(ch)
                except Exception:
                    pass
                ch.applied = None
        for b in self._backends:
            try:
                b.close()
            except Exception:
                pass
        self._backends = []
