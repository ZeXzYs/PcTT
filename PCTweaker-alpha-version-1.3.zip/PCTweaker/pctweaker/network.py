"""Network latency tuning.

Reversible parts used by the "network" tweaks:
  * AdapterTuning     - per-adapter: interrupt moderation, LSO, RSC, EEE/green power saving, power-off
  * NagleInterfaces   - per-interface TCP: TcpAckFrequency=1 + TCPNoDelay=1 (no Nagle / delayed ACK)
  * PsSetting         - a single global PowerShell-backed setting (RSC, ECN)
Plus QoS (DSCP) policy helpers, an adapter restart action and a latency test.
All previous values are recorded in the shared backup store so switching a tweak off restores them.
"""
import json
import os
import re
import socket
import statistics
import time

from .admin import powershell
from .registry import DWORD, delete_value, read_value, write_value

GUID_RE = re.compile(r"^\{[0-9A-Fa-f]{8}(-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}\}$")
SAFE_KEY = re.compile(r"^[\w*.\-]+$")
SAFE_VAL = re.compile(r"^[\w.\-]+$")
_QUOTES = "'\u2018\u2019\u201a\u201b"      # PowerShell treats all of these as single quotes


def ps_quote(s) -> str:
    s = str(s)
    if re.search(r"[\x00-\x1f]", s):
        raise ValueError("Control characters are not allowed.")
    return "'" + "".join(c * 2 if c in _QUOTES else c for c in s) + "'"


# ----------------------------------------------------------------------- adapter query
_ADAPTER_PS = r"""
$ErrorActionPreference='SilentlyContinue'
$kw=@('*InterruptModeration','*EEE','GreenEthernet','EnableGreenEthernet','PowerSavingMode','AdvancedEEE','ULPMode','EEELinkAdvertisement')
$res=@()
foreach($a in (Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' })){
  $n=$a.Name
  $adv=@()
  foreach($p in (Get-NetAdapterAdvancedProperty -Name $n)){
    if($kw -contains $p.RegistryKeyword){
      $vals=@($p.ValidRegistryValues); $disp=@($p.ValidDisplayValues)
      $i=[array]::IndexOf($vals,'0')
      if($i -ge 0 -and $disp[$i] -match '^(Disabled|Off)$' -and "$($p.RegistryValue)" -ne '0'){
        $adv+=[pscustomobject]@{k="$($p.RegistryKeyword)";v="$($p.RegistryValue)"}
      }
    }
  }
  $lso=Get-NetAdapterLso -Name $n
  $rsc=Get-NetAdapterRsc -Name $n
  $pm=Get-NetAdapterPowerManagement -Name $n
  $l=$null; if($lso){$l=[pscustomobject]@{v4=[bool]$lso.IPv4Enabled;v6=[bool]$lso.IPv6Enabled}}
  $r=$null; if($rsc){$r=[pscustomobject]@{v4=[bool]$rsc.IPv4Enabled;v6=[bool]$rsc.IPv6Enabled}}
  $m=$null; if($pm){$m="$($pm.AllowComputerToTurnOffDevice)"}
  $res+=[pscustomobject]@{name="$n";guid="$($a.InterfaceGuid)";desc="$($a.InterfaceDescription)";adv=$adv;lso=$l;rsc=$r;pm=$m}
}
ConvertTo-Json -InputObject @($res) -Depth 5 -Compress
"""

_cache = {"t": 0.0, "data": None}


def read_adapters(fresh: bool = False):
    """Active physical adapters and the offload/power settings we may change."""
    if not fresh and _cache["data"] is not None and time.time() - _cache["t"] < 4:
        return _cache["data"]
    rc, out = powershell(_ADAPTER_PS, timeout=90)
    try:
        data = json.loads(out[out.index("["):])
    except ValueError:
        raise RuntimeError(out.strip() or "Could not read the network adapters.")
    adapters = []
    for a in data or []:
        if not isinstance(a, dict) or not GUID_RE.match(str(a.get("guid", ""))):
            continue
        adapters.append({
            "name": str(a.get("name", "")), "guid": a["guid"], "desc": str(a.get("desc", "")),
            "adv": [p for p in (a.get("adv") or []) if isinstance(p, dict)],
            "lso": a.get("lso") if isinstance(a.get("lso"), dict) else None,
            "rsc": a.get("rsc") if isinstance(a.get("rsc"), dict) else None,
            "pm": a.get("pm") if isinstance(a.get("pm"), str) else None,
        })
    _cache.update(t=time.time(), data=adapters)
    return adapters


def _on(x) -> bool:
    return bool(x) and bool(x.get("v4") or x.get("v6"))


def _run_script(lines, ignore_missing=False):
    rc, out = powershell("\n".join(lines), timeout=240)
    errs = [l[4:].strip() for l in out.splitlines() if l.startswith("ERR:")]
    if ignore_missing:
        errs = [e for e in errs if not re.search(r"No MSFT_NetAdapter|not found", e, re.I)]
    if errs or (rc != 0 and not out.strip().startswith("OK")):
        raise RuntimeError("; ".join(errs) or out.strip() or "PowerShell failed.")
    _cache["data"] = None


# ----------------------------------------------------------------------- parts
class AdapterTuning:
    """Interrupt moderation off, LSO/RSC off, EEE / green power saving off, adapter power-off disallowed."""
    key = "net_adapters"

    def is_applied(self, store) -> bool:
        rec = store.get(self.key)
        if not rec:
            return False
        cur = {a["name"]: a for a in read_adapters()}
        checked = False
        for r in rec:
            a = cur.get(r["name"])
            if a is None:
                continue
            checked = True
            if a["adv"] or _on(a["lso"]) or _on(a["rsc"]) or a["pm"] == "Enabled":
                return False
        return checked

    def apply(self, store):
        adapters = read_adapters(fresh=True)
        if not adapters:
            raise RuntimeError("No active network adapter found.")
        rec = store.setdefault(self.key, [])
        known = {r["name"] for r in rec}
        lines = ["$ErrorActionPreference='Stop'"]
        for a in adapters:
            if a["name"] not in known:
                rec.append({k: a[k] for k in ("name", "guid", "adv", "lso", "rsc", "pm")})
            n = ps_quote(a["name"])
            body = []
            for p in a["adv"]:
                if SAFE_KEY.match(str(p.get("k", ""))):
                    body.append(f"Set-NetAdapterAdvancedProperty -Name {n} -RegistryKeyword "
                                f"{ps_quote(p['k'])} -RegistryValue '0' -NoRestart")
            if _on(a["lso"]):
                body.append(f"Disable-NetAdapterLso -Name {n}")
            if _on(a["rsc"]):
                body.append(f"Disable-NetAdapterRsc -Name {n}")
            if a["pm"] == "Enabled":
                body.append(f"Set-NetAdapterPowerManagement -Name {n} -AllowComputerToTurnOffDevice Disabled")
            if body:
                lines.append("try{" + ";".join(body) + f";Restart-NetAdapter -Name {n}"
                             "}catch{Write-Output ('ERR:'+$_.Exception.Message)}")
        _run_script(lines)

    def revert(self, store):
        rec = store.get(self.key) or []
        lines = ["$ErrorActionPreference='Stop'"]
        for r in rec:
            n = ps_quote(r["name"])
            body = []
            for p in r.get("adv") or []:
                k, v = str(p.get("k", "")), str(p.get("v", ""))
                if SAFE_KEY.match(k) and SAFE_VAL.match(v):
                    body.append(f"Set-NetAdapterAdvancedProperty -Name {n} -RegistryKeyword "
                                f"{ps_quote(k)} -RegistryValue {ps_quote(v)} -NoRestart")
            for cmd, state in (("Lso", r.get("lso")), ("Rsc", r.get("rsc"))):
                if state:
                    for flag, key in (("-IPv4", "v4"), ("-IPv6", "v6")):
                        if state.get(key):
                            body.append(f"Enable-NetAdapter{cmd} -Name {n} {flag}")
            if r.get("pm") == "Enabled":
                body.append(f"Set-NetAdapterPowerManagement -Name {n} -AllowComputerToTurnOffDevice Enabled")
            if body:
                lines.append("try{" + ";".join(body) + f";Restart-NetAdapter -Name {n}"
                             "}catch{Write-Output ('ERR:'+$_.Exception.Message)}")
        if len(lines) > 1:
            _run_script(lines, ignore_missing=True)


class NagleInterfaces:
    """TcpAckFrequency=1 and TCPNoDelay=1 on every active adapter's TCP interface."""
    base = r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
    values = (("TcpAckFrequency", 1), ("TCPNoDelay", 1))

    def is_applied(self, store) -> bool:
        guids = store.get("nagle_guids")
        if not guids:
            return False
        return all(read_value("HKLM", f"{self.base}\\{g}", n).get("data") == v
                   for g in guids for n, v in self.values)

    def apply(self, store):
        guids = [a["guid"] for a in read_adapters(fresh=True)]
        if not guids:
            raise RuntimeError("No active network adapter found.")
        saved = store.setdefault("nagle_guids", [])
        prev = store.setdefault("nagle_prev", {})
        for g in guids:
            if g not in saved:
                saved.append(g)
            for name, val in self.values:
                pk = f"{g}\\{name}"
                if pk not in prev:
                    prev[pk] = read_value("HKLM", f"{self.base}\\{g}", name)
                write_value("HKLM", f"{self.base}\\{g}", name, DWORD, val)

    def revert(self, store):
        prev = store.get("nagle_prev", {})
        for g in store.get("nagle_guids", []):
            if not GUID_RE.match(g):
                continue
            for name, _ in self.values:
                old = prev.get(f"{g}\\{name}")
                path = f"{self.base}\\{g}"
                if old and old.get("exists"):
                    write_value("HKLM", path, name, old["type"], old["data"])
                else:
                    delete_value("HKLM", path, name)


class PsSetting:
    """One global setting read/written through PowerShell (values are whitelisted to letters only)."""

    def __init__(self, key, get_script, set_script, target):
        self.key, self.get_script, self.set_script, self.target = key, get_script, set_script, target

    def _read(self):
        rc, out = powershell(self.get_script, timeout=60)
        lines = [l.strip() for l in out.splitlines() if l.strip()]
        return lines[-1] if lines and re.fullmatch(r"[A-Za-z]+", lines[-1]) else None

    def _write(self, value):
        if not re.fullmatch(r"[A-Za-z]+", value):
            raise RuntimeError("Refusing to apply an unexpected value.")
        rc, out = powershell(self.set_script.format(v=value) + " -ErrorAction Stop", timeout=60)
        if rc != 0:
            raise RuntimeError(out.strip() or "PowerShell failed.")

    def is_applied(self, store) -> bool:
        return self._read() == self.target

    def apply(self, store):
        cur = self._read()
        if self.key not in store and cur:
            store[self.key] = cur
        self._write(self.target)

    def revert(self, store):
        prev = store.get(self.key)
        if prev:
            self._write(prev)


# ----------------------------------------------------------------------- QoS (DSCP) policies
QOS_PREFIX = "PC Tweaker - "
SAFE_EXE = re.compile(r"^[\w .()\-]+\.exe$", re.I)


def list_qos_policies():
    script = (
        "$ErrorActionPreference='SilentlyContinue';"
        "$r=@(Get-NetQosPolicy | Where-Object { $_.Name -like 'PC Tweaker - *' } | ForEach-Object "
        "{ [pscustomobject]@{name=\"$($_.Name)\";app=\"$($_.AppPathNameMatchCondition)\";dscp=\"$($_.DSCPAction)\"} });"
        "ConvertTo-Json -InputObject @($r) -Depth 3 -Compress")
    rc, out = powershell(script, timeout=60)
    try:
        data = json.loads(out[out.index("["):])
    except ValueError:
        return []
    return [p for p in data if isinstance(p, dict) and str(p.get("name", "")).startswith(QOS_PREFIX)]


def add_qos_policy(path: str) -> str:
    exe = os.path.basename(path.strip().strip('"').replace("/", "\\").split("\\")[-1])
    if not SAFE_EXE.match(exe):
        raise ValueError("Pick a program (.exe) with a normal file name.")
    name = QOS_PREFIX + exe
    rc, out = powershell(
        f"New-NetQosPolicy -Name {ps_quote(name)} -AppPathNameMatchCondition {ps_quote(exe)} "
        "-DSCPAction 46 -NetworkProfile All -ErrorAction Stop | Out-Null", timeout=60)
    if rc != 0:
        raise RuntimeError(out.strip() or "Could not create the QoS policy (run as administrator).")
    return f"Traffic from {exe} will be tagged high priority (DSCP 46)."


def remove_qos_policy(name: str) -> str:
    if not name.startswith(QOS_PREFIX) or not SAFE_EXE.match(name[len(QOS_PREFIX):]):
        raise ValueError("That isn't one of PC Tweaker's policies.")
    rc, out = powershell(f"Remove-NetQosPolicy -Name {ps_quote(name)} -Confirm:$false -ErrorAction Stop", timeout=60)
    if rc != 0:
        raise RuntimeError(out.strip() or "Could not remove the policy.")
    return f"Removed policy for {name[len(QOS_PREFIX):]}."


# ----------------------------------------------------------------------- actions
def restart_adapters() -> str:
    rc, out = powershell(
        "Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' } | Restart-NetAdapter -ErrorAction Stop",
        timeout=120)
    if rc != 0:
        raise RuntimeError(out.strip() or "Could not restart the adapters.")
    _cache["data"] = None
    return "Network adapters restarted."


_last = {}


def latency_test(host="1.1.1.1", port=443, count=20, timeout=2.0) -> str:
    """TCP-handshake round trips: a locale-independent stand-in for ping (also measures jitter)."""
    samples, lost = [], 0
    for _ in range(count):
        t0 = time.perf_counter()
        try:
            with socket.create_connection((host, port), timeout=timeout):
                pass
            samples.append((time.perf_counter() - t0) * 1000)
        except OSError:
            lost += 1
        time.sleep(0.15)
    if not samples:
        raise RuntimeError(f"Could not reach {host}:{port} - check your internet connection.")
    avg = statistics.fmean(samples)
    jitter = statistics.fmean(abs(b - a) for a, b in zip(samples, samples[1:])) if len(samples) > 1 else 0.0
    msg = (f"Latency to {host}: avg {avg:.1f} ms (min {min(samples):.1f}, max {max(samples):.1f}), "
           f"jitter {jitter:.1f} ms, lost {lost}/{count}")
    if "avg" in _last:
        msg += f". Previous run: {_last['avg']:.1f} ms ({avg - _last['avg']:+.1f} ms)"
    _last["avg"] = avg
    return msg
